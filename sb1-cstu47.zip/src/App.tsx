import { Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/HomePage';
import { LearnMorePage } from './pages/LearnMorePage';
import { AuthPage } from './pages/AuthPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage';
import { CreateMealPlanPage } from './pages/CreateMealPlanPage';
import { MealPlanPage } from './pages/MealPlanPage';
import { ShoppingListPage } from './pages/ShoppingListPage';
import { PantryPage } from './pages/PantryPage';
import { Navbar } from './components/Navbar';

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/learn-more" element={<LearnMorePage />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/onboarding" element={<OnboardingPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/settings" element={<ProfileSettingsPage />} />
        <Route path="/meal-plan/create" element={<CreateMealPlanPage />} />
        <Route path="/meal-plan/:id" element={<MealPlanPage />} />
        <Route path="/shopping-list" element={<ShoppingListPage />} />
        <Route path="/pantry" element={<PantryPage />} />
      </Routes>
    </div>
  );
}