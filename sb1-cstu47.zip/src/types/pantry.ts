export interface PantryItem {
  id: string;
  name: string;
  amount: number;
  unit: string;
  category: 'produce' | 'meat' | 'dairy' | 'pantry' | 'spices' | 'frozen' | 'other';
  expiration_date?: string;
  user_id: string;
}