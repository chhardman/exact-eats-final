export interface UserProfile {
  id: string;
  height?: number;
  weight?: number;
  activity_level?: 'not_active' | 'moderately_active' | 'very_active';
  primary_goal?: 'lose_weight' | 'maintain_weight' | 'gain_muscle' | 'eat_healthier';
  dietary_restrictions?: string[];
  cooking_for?: number;
  created_at?: string;
  updated_at?: string;
}