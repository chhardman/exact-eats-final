export interface Recipe {
  id: string;
  name: string;
  description: string;
  instructions: string[];
  ingredients: {
    item: string;
    amount: number;
    unit: string;
  }[];
  prep_time_minutes: number;
  cook_time_minutes: number;
  difficulty: 'easy' | 'medium' | 'hard';
  calories: number;
  protein_grams: number;
  carbs_grams: number;
  fat_grams: number;
  servings: number;
}

export interface MealPlanDay {
  date: string;
  meals: {
    id: string;
    type: string;
    recipe: Recipe;
    servings: number;
    order_in_day: number;
  }[];
  total_calories: number;
  total_protein: number;
  total_carbs: number;
  total_fat: number;
}

export interface MealPlan {
  id: string;
  start_date: string;
  days: MealPlanDay[];
  user_id: string;
}