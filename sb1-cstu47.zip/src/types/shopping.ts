export type Category = 'produce' | 'meat' | 'dairy' | 'pantry' | 'spices' | 'frozen' | 'other';

export interface ShoppingListItem {
  id: string;
  shopping_list_id: string;
  item: string;
  amount: number;
  unit: string;
  category: Category;
  checked: boolean;
}

export interface ShoppingList {
  id: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  meal_plan_id: string | null;
  name: string;
  notes: string | null;
}