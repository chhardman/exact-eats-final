import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../components/Button';
import { PantryList } from '../components/pantry/PantryList';
import { AddPantryItem } from '../components/pantry/AddPantryItem';
import { supabase } from '../lib/supabase';
import type { PantryItem } from '../types/pantry';

export function PantryPage() {
  const [items, setItems] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddItem, setShowAddItem] = useState(false);
  const [view, setView] = useState<'list' | 'expiring'>('list');

  useEffect(() => {
    loadPantryItems();
  }, []);

  async function loadPantryItems() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('pantry_items')
        .select('*')
        .eq('user_id', user.id)
        .order('name');

      if (error) throw error;

      setItems(data || []);
    } catch (error) {
      console.error('Error loading pantry items:', error);
    } finally {
      setLoading(false);
    }
  }

  const expiringItems = items.filter(
    item => item.expiration_date && new Date(item.expiration_date) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading your pantry...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-display font-bold text-charcoal">
              Pantry
            </h1>
            <div className="flex gap-4">
              <Button onClick={() => setShowAddItem(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </div>
          </div>

          {expiringItems.length > 0 && (
            <div className="mb-8 p-4 bg-warm-gold/10 rounded-lg">
              <h2 className="text-lg font-semibold mb-2">Expiring Soon</h2>
              <div className="flex flex-wrap gap-2">
                {expiringItems.map(item => (
                  <span
                    key={item.id}
                    className="bg-warm-gold/20 text-deep-olive px-3 py-1 rounded-full text-sm"
                  >
                    {item.name} ({item.amount} {item.unit})
                  </span>
                ))}
              </div>
            </div>
          )}

          <PantryList
            items={view === 'list' ? items : expiringItems}
            onUpdate={loadPantryItems}
          />
        </div>
      </div>

      {showAddItem && (
        <AddPantryItem
          onClose={() => setShowAddItem(false)}
          onItemAdded={loadPantryItems}
        />
      )}
    </div>
  );
}