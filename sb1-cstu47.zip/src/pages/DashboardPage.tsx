import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/Button';
import { supabase } from '../lib/supabase';
import { ChefHat, ShoppingCart, Package, Crown, Calendar, Clock, Sparkles } from 'lucide-react';
import type { Database } from '../lib/database.types';
import type { MealPlan } from '../types/meal-plan';

type Profile = Database['public']['Tables']['profiles']['Row'];

export function DashboardPage() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [latestMealPlan, setLatestMealPlan] = useState<MealPlan | null>(null);

  useEffect(() => {
    async function loadProfile() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          navigate('/auth');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        
        if (error) throw error;

        if (data) {
          setProfile(data);
          loadLatestMealPlan(user.id);
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [navigate]);

  const loadLatestMealPlan = async (userId: string) => {
    try {
      const { data: mealPlan } = await supabase
        .from('meal_plans')
        .select(`
          *,
          meal_plan_items:meal_plan_items(
            *,
            recipe:recipes(*)
          )
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (mealPlan) {
        setLatestMealPlan(mealPlan);
      }
    } catch (error) {
      console.error('Error loading latest meal plan:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container mx-auto px-4">
        <div className="grid gap-8">
          {/* Welcome Section */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-display font-bold text-charcoal">Welcome Back!</h1>
                <p className="text-deep-olive mt-2">
                  {profile?.subscription_tier === 'premium' ? (
                    <span className="flex items-center gap-2">
                      <Crown className="w-5 h-5 text-warm-gold" />
                      Premium Member
                    </span>
                  ) : (
                    'Free Plan'
                  )}
                </p>
              </div>
              {profile?.subscription_tier === 'free' && (
                <Button>
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium
                </Button>
              )}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <Calendar className="w-8 h-8 text-terracotta mb-4" />
              <h3 className="text-lg font-semibold mb-2">Current Meal Plan</h3>
              {latestMealPlan ? (
                <div>
                  <p className="text-deep-olive mb-4">
                    {latestMealPlan.days} day plan starting {new Date(latestMealPlan.start_date).toLocaleDateString()}
                  </p>
                  <Button 
                    className="w-full"
                    onClick={() => navigate(`/meal-plan/${latestMealPlan.id}`)}
                  >
                    View Plan
                  </Button>
                </div>
              ) : (
                <div>
                  <p className="text-deep-olive mb-4">No active meal plan</p>
                  <Button 
                    className="w-full"
                    onClick={() => navigate('/meal-plan/create')}
                  >
                    Create Plan
                  </Button>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <Clock className="w-8 h-8 text-terracotta mb-4" />
              <h3 className="text-lg font-semibold mb-2">Recent Activity</h3>
              <p className="text-deep-olive">Profile completed</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <Sparkles className="w-8 h-8 text-terracotta mb-4" />
              <h3 className="text-lg font-semibold mb-2">Achievements</h3>
              <p className="text-deep-olive">Getting Started 🎉</p>
            </div>
          </div>

          {/* Main Actions */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <ChefHat className="w-8 h-8 text-terracotta mb-4" />
              <h2 className="text-xl font-semibold mb-2">Meal Planning</h2>
              <p className="text-deep-olive mb-4">
                {profile?.subscription_tier === 'premium' 
                  ? 'Generate your next weekly meal plan'
                  : 'Create your 3-day meal plan'}
              </p>
              <Button 
                className="w-full"
                onClick={() => navigate('/meal-plan/create')}
              >
                Start Planning
              </Button>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <ShoppingCart className="w-8 h-8 text-terracotta mb-4" />
              <h2 className="text-xl font-semibold mb-2">Shopping List</h2>
              <p className="text-deep-olive mb-4">
                {profile?.subscription_tier === 'premium'
                  ? 'View and manage your shopping list'
                  : 'Upgrade to access shopping lists'}
              </p>
              <Button 
                className="w-full"
                onClick={() => navigate('/shopping-list')}
                disabled={profile?.subscription_tier !== 'premium'}
              >
                View List
              </Button>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <Package className="w-8 h-8 text-terracotta mb-4" />
              <h2 className="text-xl font-semibold mb-2">Pantry</h2>
              <p className="text-deep-olive mb-4">
                {profile?.subscription_tier === 'premium'
                  ? 'Manage your pantry inventory'
                  : 'Upgrade to access pantry management'}
              </p>
              <Button 
                className="w-full"
                onClick={() => navigate('/pantry')}
                disabled={profile?.subscription_tier !== 'premium'}
              >
                View Pantry
              </Button>
            </div>
          </div>

          {/* Getting Started Guide */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-2xl font-display font-bold mb-6">Getting Started</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-cream rounded-full flex items-center justify-center text-terracotta font-bold">
                  1
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Create Your First Meal Plan</h3>
                  <p className="text-deep-olive">Start with a 3-day plan tailored to your preferences</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-cream rounded-full flex items-center justify-center text-terracotta font-bold">
                  2
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Review Your Shopping List</h3>
                  <p className="text-deep-olive">Get all ingredients needed for your meals</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-cream rounded-full flex items-center justify-center text-terracotta font-bold">
                  3
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Track Your Progress</h3>
                  <p className="text-deep-olive">Monitor your cooking journey and achievements</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}