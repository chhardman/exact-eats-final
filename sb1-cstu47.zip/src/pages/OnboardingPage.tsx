import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../components/Button';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Insert'];

interface FormData {
  height: string;
  height_unit: 'cm' | 'in';
  weight: string;
  weight_unit: 'kg' | 'lb';
  activity_level: string;
  primary_goal: string;
  dietary_restrictions: string[];
  cooking_for: string;
  subscription_tier: 'free' | 'premium';
  subscription_status: 'active' | 'inactive';
}

interface StepProps {
  formData: FormData;
  updateFormData: (updates: Partial<FormData>) => void;
  onNext?: () => void;
  onBack?: () => void;
  onSubmit?: () => void;
}

function BasicsStep({ formData, updateFormData, onNext }: StepProps) {
  return (
    <div>
      <h2 className="text-2xl font-display font-bold mb-6">Let's Get Started</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Height</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={formData.height}
              onChange={(e) => updateFormData({ height: e.target.value })}
              className="flex-1 p-2 border rounded-lg"
              placeholder={formData.height_unit === 'cm' ? 'Height in cm' : 'Height in inches'}
            />
            <select
              value={formData.height_unit}
              onChange={(e) => updateFormData({ height_unit: e.target.value as 'cm' | 'in' })}
              className="w-24 p-2 border rounded-lg"
            >
              <option value="cm">cm</option>
              <option value="in">inches</option>
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Weight</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={formData.weight}
              onChange={(e) => updateFormData({ weight: e.target.value })}
              className="flex-1 p-2 border rounded-lg"
              placeholder={formData.weight_unit === 'kg' ? 'Weight in kg' : 'Weight in pounds'}
            />
            <select
              value={formData.weight_unit}
              onChange={(e) => updateFormData({ weight_unit: e.target.value as 'kg' | 'lb' })}
              className="w-24 p-2 border rounded-lg"
            >
              <option value="kg">kg</option>
              <option value="lb">lb</option>
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Activity Level</label>
          <select
            value={formData.activity_level}
            onChange={(e) => updateFormData({ activity_level: e.target.value })}
            className="w-full p-2 border rounded-lg"
          >
            <option value="">Select activity level</option>
            <option value="not_active">Not Very Active</option>
            <option value="moderately_active">Moderately Active</option>
            <option value="very_active">Very Active</option>
          </select>
        </div>
        <Button onClick={onNext} className="w-full">
          Next <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}

function GoalsStep({ formData, updateFormData, onNext, onBack }: StepProps) {
  return (
    <div>
      <h2 className="text-2xl font-display font-bold mb-6">Your Goals</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Primary Goal</label>
          <select
            value={formData.primary_goal}
            onChange={(e) => updateFormData({ primary_goal: e.target.value })}
            className="w-full p-2 border rounded-lg"
          >
            <option value="">Select your goal</option>
            <option value="lose_weight">Lose Weight</option>
            <option value="maintain_weight">Maintain Weight</option>
            <option value="gain_muscle">Gain Muscle</option>
            <option value="eat_healthier">Eat Healthier</option>
          </select>
        </div>
        <div className="flex gap-4">
          <Button variant="secondary" onClick={onBack}>
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={onNext} className="flex-1">
            Next <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function DietaryStep({ formData, updateFormData, onNext, onBack }: StepProps) {
  const [customRestriction, setCustomRestriction] = useState('');

  const toggleRestriction = (restriction: string) => {
    const current = formData.dietary_restrictions || [];
    const updated = current.includes(restriction)
      ? current.filter(r => r !== restriction)
      : [...current, restriction];
    updateFormData({ dietary_restrictions: updated });
  };

  const handleAddCustom = () => {
    if (customRestriction && !formData.dietary_restrictions?.includes(customRestriction)) {
      updateFormData({
        dietary_restrictions: [...(formData.dietary_restrictions || []), customRestriction]
      });
      setCustomRestriction('');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-display font-bold mb-6">Dietary Preferences</h2>
      <div className="space-y-4">
        <div className="space-y-2">
          {['vegetarian', 'vegan', 'gluten-free', 'dairy-free'].map((restriction) => (
            <label key={restriction} className="flex items-center">
              <input
                type="checkbox"
                checked={formData.dietary_restrictions?.includes(restriction)}
                onChange={() => toggleRestriction(restriction)}
                className="mr-2"
              />
              {restriction.charAt(0).toUpperCase() + restriction.slice(1)}
            </label>
          ))}
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium">Custom Dietary Restriction</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={customRestriction}
              onChange={(e) => setCustomRestriction(e.target.value)}
              className="flex-1 p-2 border rounded-lg"
              placeholder="Enter custom restriction"
            />
            <Button onClick={handleAddCustom} size="sm">Add</Button>
          </div>
        </div>
        {formData.dietary_restrictions?.length > 0 && (
          <div className="mt-4">
            <label className="block text-sm font-medium mb-2">Current Restrictions:</label>
            <div className="flex flex-wrap gap-2">
              {formData.dietary_restrictions.map((restriction) => (
                <span
                  key={restriction}
                  className="bg-cream px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  {restriction}
                  <button
                    onClick={() => toggleRestriction(restriction)}
                    className="text-terracotta hover:text-burnt-orange"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}
        <div className="flex gap-4 mt-6">
          <Button variant="secondary" onClick={onBack}>
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={onNext} className="flex-1">
            Next <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function PlanStep({ formData, updateFormData, onSubmit, onBack }: StepProps) {
  return (
    <div>
      <h2 className="text-2xl font-display font-bold mb-6">Choose Your Plan</h2>
      <div className="space-y-6">
        <div className="space-y-4">
          <div className="border rounded-lg p-4 cursor-pointer hover:border-terracotta"
               onClick={() => updateFormData({ subscription_tier: 'free' })}>
            <div className="flex items-center">
              <input
                type="radio"
                checked={formData.subscription_tier === 'free'}
                onChange={() => updateFormData({ subscription_tier: 'free' })}
                className="mr-2"
              />
              <div>
                <h3 className="font-semibold">Free Plan</h3>
                <p className="text-sm text-gray-600">One 3-day meal plan</p>
              </div>
            </div>
          </div>
          <div className="border rounded-lg p-4 cursor-pointer hover:border-terracotta"
               onClick={() => updateFormData({ subscription_tier: 'premium' })}>
            <div className="flex items-center">
              <input
                type="radio"
                checked={formData.subscription_tier === 'premium'}
                onChange={() => updateFormData({ subscription_tier: 'premium' })}
                className="mr-2"
              />
              <div>
                <h3 className="font-semibold">Premium Plan - $25/month</h3>
                <p className="text-sm text-gray-600">Weekly meal plans, shopping lists, and more</p>
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-4">
          <Button variant="secondary" onClick={onBack}>
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={onSubmit} className="flex-1">
            Complete Setup
          </Button>
        </div>
      </div>
    </div>
  );
}

export function OnboardingPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState<FormData>({
    height: '',
    height_unit: 'cm',
    weight: '',
    weight_unit: 'kg',
    activity_level: '',
    primary_goal: '',
    dietary_restrictions: [],
    cooking_for: '1',
    subscription_tier: 'free',
    subscription_status: 'active'
  });

  useEffect(() => {
    async function checkProfile() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          navigate('/auth');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;

        // If profile has essential data, redirect to dashboard
        if (data && data.height && data.weight && data.activity_level && data.primary_goal) {
          navigate('/dashboard');
          return;
        }

        // If profile exists but incomplete, pre-fill the form
        if (data) {
          setFormData(prev => ({
            ...prev,
            height: data.height?.toString() || '',
            height_unit: data.height_unit || 'cm',
            weight: data.weight?.toString() || '',
            weight_unit: data.weight_unit || 'kg',
            activity_level: data.activity_level || '',
            primary_goal: data.primary_goal || '',
            dietary_restrictions: data.dietary_restrictions || [],
            cooking_for: data.cooking_for?.toString() || '1',
            subscription_tier: data.subscription_tier || 'free',
            subscription_status: data.subscription_status || 'active'
          }));
        }
      } catch (error) {
        console.error('Error checking profile:', error);
      } finally {
        setLoading(false);
      }
    }

    checkProfile();
  }, [navigate]);

  const updateFormData = (updates: Partial<FormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleSubmit = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const profileData: Profile = {
        id: user.id,
        height: parseFloat(formData.height) || null,
        height_unit: formData.height_unit,
        weight: parseFloat(formData.weight) || null,
        weight_unit: formData.weight_unit,
        activity_level: formData.activity_level || null,
        primary_goal: formData.primary_goal || null,
        dietary_restrictions: formData.dietary_restrictions,
        cooking_for: parseInt(formData.cooking_for) || null,
        subscription_tier: formData.subscription_tier,
        subscription_status: formData.subscription_status,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('profiles')
        .upsert(profileData);

      if (error) throw error;

      navigate('/dashboard');
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading...</p>
        </div>
      </div>
    );
  }

  const steps = [
    <BasicsStep key="basics" formData={formData} updateFormData={updateFormData} onNext={() => setStep(1)} />,
    <GoalsStep key="goals" formData={formData} updateFormData={updateFormData} onNext={() => setStep(2)} onBack={() => setStep(0)} />,
    <DietaryStep key="dietary" formData={formData} updateFormData={updateFormData} onNext={() => setStep(3)} onBack={() => setStep(1)} />,
    <PlanStep key="plan" formData={formData} updateFormData={updateFormData} onSubmit={handleSubmit} onBack={() => setStep(2)} />
  ];

  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="bg-white p-8 rounded-2xl shadow-lg">
          {steps[step]}
        </div>
      </div>
    </div>
  );
}