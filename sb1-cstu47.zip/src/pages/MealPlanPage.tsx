import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, List } from 'lucide-react';
import { Button } from '../components/Button';
import { WeeklyView } from '../components/meal-plan/WeeklyView';
import { DailyView } from '../components/meal-plan/DailyView';
import { ShoppingList } from '../components/meal-plan/ShoppingList';
import { MealPlanSummary } from '../components/meal-plan/MealPlanSummary';
import { supabase } from '../lib/supabase';
import type { MealPlan } from '../types/meal-plan';

export function MealPlanPage() {
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const [mealPlan, setMealPlan] = useState<MealPlan | null>(null);
  const [view, setView] = useState<'weekly' | 'daily'>('weekly');
  const [showShoppingList, setShowShoppingList] = useState(false);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadMealPlan();
    }
  }, [id]);

  async function loadMealPlan() {
    try {
      const { data: mealPlanData, error: mealPlanError } = await supabase
        .from('meal_plans')
        .select('*')
        .eq('id', id)
        .single();

      if (mealPlanError) throw mealPlanError;

      const { data: mealItems, error: itemsError } = await supabase
        .from('meal_plan_items')
        .select(`
          id,
          meal_type,
          servings,
          order_in_day,
          day_number,
          recipe:recipes (*)
        `)
        .eq('meal_plan_id', id)
        .order('day_number, order_in_day');

      if (itemsError) throw itemsError;

      // Transform the data into our MealPlan type
      const days: MealPlan['days'] = [];
      const startDate = new Date(mealPlanData.start_date);

      for (let i = 0; i < mealPlanData.days; i++) {
        const date = new Date(startDate);
        date.setDate(date.getDate() + i);
        
        const dayMeals = mealItems.filter(item => item.day_number === i + 1);
        
        const totals = dayMeals.reduce((acc, meal) => ({
          calories: acc.calories + (meal.recipe.calories * meal.servings),
          protein: acc.protein + (meal.recipe.protein_grams * meal.servings),
          carbs: acc.carbs + (meal.recipe.carbs_grams * meal.servings),
          fat: acc.fat + (meal.recipe.fat_grams * meal.servings)
        }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

        days.push({
          date: date.toISOString().split('T')[0],
          meals: dayMeals.map(item => ({
            id: item.id,
            type: item.meal_type,
            recipe: item.recipe,
            servings: item.servings,
            order_in_day: item.order_in_day
          })),
          total_calories: totals.calories,
          total_protein: totals.protein,
          total_carbs: totals.carbs,
          total_fat: totals.fat
        });
      }

      setMealPlan({
        id: mealPlanData.id,
        start_date: mealPlanData.start_date,
        days,
        user_id: mealPlanData.user_id
      });

      setSelectedDay(days[0].date);
    } catch (error) {
      console.error('Error loading meal plan:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleSwapMeal = async (mealId: string, targetMealId: string) => {
    try {
      // Get the meals
      const { data: meals, error: fetchError } = await supabase
        .from('meal_plan_items')
        .select('*')
        .in('id', [mealId, targetMealId]);

      if (fetchError) throw fetchError;

      const [meal1, meal2] = meals;
      
      // Swap their day numbers and order
      const { error: updateError } = await supabase
        .from('meal_plan_items')
        .upsert([
          {
            ...meal1,
            day_number: meal2.day_number,
            order_in_day: meal2.order_in_day
          },
          {
            ...meal2,
            day_number: meal1.day_number,
            order_in_day: meal1.order_in_day
          }
        ]);

      if (updateError) throw updateError;

      // Reload meal plan
      await loadMealPlan();
    } catch (error) {
      console.error('Error swapping meals:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading your meal plan...</p>
        </div>
      </div>
    );
  }

  if (!mealPlan) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <p className="text-deep-olive">Meal plan not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container mx-auto px-4">
        <div className="space-y-8">
          <MealPlanSummary mealPlan={mealPlan} />

          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-3xl font-display font-bold text-charcoal">
                Your Meal Plan
              </h1>
              <div className="flex gap-4">
                <Button
                  variant={view === 'weekly' ? 'primary' : 'secondary'}
                  onClick={() => setView('weekly')}
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Weekly View
                </Button>
                <Button
                  variant={view === 'daily' ? 'primary' : 'secondary'}
                  onClick={() => setView('daily')}
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Daily View
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => setShowShoppingList(true)}
                >
                  <List className="w-4 h-4 mr-2" />
                  Shopping List
                </Button>
              </div>
            </div>

            {view === 'weekly' ? (
              <WeeklyView
                mealPlan={mealPlan}
                selectedDay={selectedDay}
                onDaySelect={setSelectedDay}
                onSwapMeal={handleSwapMeal}
              />
            ) : (
              <DailyView
                day={mealPlan.days.find(d => d.date === selectedDay)!}
                onServingsChange={async (mealId: string, servings: number) => {
                  try {
                    const { error } = await supabase
                      .from('meal_plan_items')
                      .update({ servings })
                      .eq('id', mealId);

                    if (error) throw error;

                    await loadMealPlan();
                  } catch (error) {
                    console.error('Error updating servings:', error);
                  }
                }}
              />
            )}
          </div>
        </div>
      </div>

      {showShoppingList && (
        <ShoppingList
          mealPlan={mealPlan}
          onClose={() => setShowShoppingList(false)}
        />
      )}
    </div>
  );
}