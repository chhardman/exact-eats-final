import { useNavigate } from 'react-router-dom';
import { Button } from '../components/Button';
import { PricingCard } from '../components/PricingCard';
import { TestimonialCard } from '../components/TestimonialCard';
import { ChefHat, ShoppingCart, Package } from 'lucide-react';

export function HomePage() {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/auth');
  };

  return (
    <div className="bg-cream">
      {/* Hero Section */}
      <section className="bg-white section-padding">
        <div className="container mx-auto container-padding">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="lg:w-1/2 space-y-6">
              <h1 className="text-5xl font-display font-bold text-charcoal">
                AI-Powered Meal Planning Made Simple
              </h1>
              <p className="text-xl text-deep-olive">
                Take the stress out of meal planning with personalized recipes, smart shopping lists, and automated pantry management.
              </p>
              <div className="flex gap-4">
                <Button size="lg" onClick={handleGetStarted}>
                  Get Started Free
                </Button>
                <Button variant="secondary" size="lg" onClick={() => navigate('/learn-more')}>
                  Learn More
                </Button>
              </div>
            </div>
            <div className="lg:w-1/2">
              <img
                src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
                alt="Healthy meal preparation"
                className="rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding">
        <div className="container mx-auto container-padding">
          <h2 className="text-4xl font-display font-bold text-center mb-16">
            Smart Features for Better Meals
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <ChefHat className="w-12 h-12 text-terracotta mb-6" />
              <h3 className="text-2xl font-bold mb-4">AI Meal Planning</h3>
              <p className="text-deep-olive">
                Get personalized meal plans based on your preferences, dietary restrictions, and health goals.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <ShoppingCart className="w-12 h-12 text-terracotta mb-6" />
              <h3 className="text-2xl font-bold mb-4">Smart Shopping List</h3>
              <p className="text-deep-olive">
                Automatically generated shopping lists with intelligent organization and budget tracking.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <Package className="w-12 h-12 text-terracotta mb-6" />
              <h3 className="text-2xl font-bold mb-4">Pantry Management</h3>
              <p className="text-deep-olive">
                Track your ingredients, get expiration alerts, and reduce food waste effortlessly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-white section-padding">
        <div className="container mx-auto container-padding">
          <h2 className="text-4xl font-display font-bold text-center mb-16">
            What Our Users Say
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <TestimonialCard
              quote="Exact Eats has completely transformed how I plan and prepare meals. It's like having a personal chef!"
              author="Sarah Johnson"
              role="Busy Parent"
              image="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80"
            />
            <TestimonialCard
              quote="The AI suggestions are spot-on, and I've discovered so many new recipes that my family loves."
              author="Michael Chen"
              role="Home Cook"
              image="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80"
            />
            <TestimonialCard
              quote="The shopping list feature saves me hours each week. No more forgotten ingredients!"
              author="Emma Rodriguez"
              role="Fitness Enthusiast"
              image="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80"
            />
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="section-padding">
        <div className="container mx-auto container-padding">
          <h2 className="text-4xl font-display font-bold text-center mb-16">
            Choose Your Plan
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <PricingCard
              title="Free"
              price="Free"
              features={[
                "One 3-day meal plan",
                "Basic recipe access",
                "Manual shopping list",
                "Email support"
              ]}
              onGetStarted={handleGetStarted}
            />
            <PricingCard
              title="Premium"
              price="$25"
              features={[
                "Weekly meal plans (5/month)",
                "Advanced recipe customization",
                "Smart shopping list",
                "Pantry management",
                "Priority support"
              ]}
              isPopular
              onGetStarted={handleGetStarted}
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white section-padding">
        <div className="container mx-auto container-padding text-center">
          <h2 className="text-4xl font-display font-bold mb-6">
            Ready to Transform Your Meal Planning?
          </h2>
          <p className="text-xl text-deep-olive mb-8 max-w-2xl mx-auto">
            Join thousands of happy users who have made cooking and meal planning easier with Exact Eats.
          </p>
          <Button size="lg" onClick={handleGetStarted}>
            Get Started Free
          </Button>
        </div>
      </section>
    </div>
  );
}