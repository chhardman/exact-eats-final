import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../components/Button';
import { NewListModal } from '../components/shopping/NewListModal';
import { ShoppingList } from '../components/shopping/ShoppingList';
import { supabase } from '../lib/supabase';
import type { ShoppingListItem } from '../types/shopping';

interface ListWithItems {
  id: string;
  name: string;
  items: ShoppingListItem[];
}

export function ShoppingListPage() {
  const [lists, setLists] = useState<ListWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showNewList, setShowNewList] = useState(false);

  useEffect(() => {
    loadShoppingLists();
  }, []);

  const loadShoppingLists = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Please sign in to view your shopping lists');
      }

      const { data: lists, error: listsError } = await supabase
        .from('shopping_lists')
        .select('*')
        .eq('user_id', user.id)
        .eq('archived', false)
        .order('created_at', { ascending: false });

      if (listsError) throw listsError;

      const listsWithItems = await Promise.all(
        lists.map(async (list) => {
          const { data: items, error: itemsError } = await supabase
            .from('shopping_list_items')
            .select('*')
            .eq('shopping_list_id', list.id)
            .order('category', { ascending: true });

          if (itemsError) throw itemsError;

          return {
            ...list,
            items: items || []
          };
        })
      );

      setLists(listsWithItems);
    } catch (error) {
      console.error('Error loading shopping lists:', error);
      setError(
        error instanceof Error 
          ? error.message 
          : 'Failed to load shopping lists. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCreateList = async (name: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Please sign in to create a list');

      const { data: list, error } = await supabase
        .from('shopping_lists')
        .insert({
          user_id: user.id,
          name,
          archived: false
        })
        .select()
        .single();

      if (error) throw error;

      setLists(prev => [...prev, { ...list, items: [] }]);
    } catch (error) {
      console.error('Error creating list:', error);
      throw error;
    }
  };

  const handleDeleteList = async (listId: string) => {
    try {
      const { error } = await supabase
        .from('shopping_lists')
        .delete()
        .eq('id', listId);

      if (error) throw error;

      setLists(prev => prev.filter(list => list.id !== listId));
    } catch (error) {
      console.error('Error deleting list:', error);
      setError(
        error instanceof Error 
          ? error.message 
          : 'Failed to delete list. Please try again.'
      );
    }
  };

  const handleToggleItem = async (listId: string, itemId: string, checked: boolean) => {
    try {
      const { error } = await supabase
        .from('shopping_list_items')
        .update({ checked })
        .eq('id', itemId);

      if (error) throw error;

      setLists(prev => prev.map(list => {
        if (list.id === listId) {
          return {
            ...list,
            items: list.items.map(item => 
              item.id === itemId ? { ...item, checked } : item
            )
          };
        }
        return list;
      }));
    } catch (error) {
      console.error('Error updating item:', error);
      setError(
        error instanceof Error 
          ? error.message 
          : 'Failed to update item. Please try again.'
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading your shopping lists...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container mx-auto px-4">
        {error && (
          <div className="bg-spice-red/10 text-spice-red p-4 rounded-lg mb-4">
            {error}
          </div>
        )}
        
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-display font-bold text-charcoal">
              Shopping Lists
            </h1>
            <Button onClick={() => setShowNewList(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New List
            </Button>
          </div>

          {lists.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-deep-olive mb-4">No shopping lists yet.</p>
              <Button onClick={() => setShowNewList(true)}>
                Create Your First List
              </Button>
            </div>
          ) : (
            <div className="space-y-8">
              {lists.map(list => (
                <ShoppingList
                  key={list.id}
                  id={list.id}
                  name={list.name}
                  items={list.items}
                  onOptimize={loadShoppingLists}
                  onDelete={() => handleDeleteList(list.id)}
                  onToggleItem={(itemId, checked) => 
                    handleToggleItem(list.id, itemId, checked)
                  }
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {showNewList && (
        <NewListModal
          onClose={() => setShowNewList(false)}
          onSubmit={handleCreateList}
        />
      )}
    </div>
  );
}