import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Calculator } from 'lucide-react';
import { Button } from '../components/Button';
import { MacroCalculator } from '../components/meal-plan/MacroCalculator';
import { PreferencesStep } from '../components/meal-plan/PreferencesStep';
import { NutritionGoalsStep } from '../components/meal-plan/NutritionGoalsStep';
import { ReviewStep } from '../components/meal-plan/ReviewStep';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface MealPlanFormData {
  startDate: string;
  days: number;
  prompt: string;
  totalCalories: string;
  proteinGoal: string;
  carbsGoal: string;
  fatGoal: string;
  mealTypes: string[];
  excludedIngredients: string[];
  preferences: string[];
}

export function CreateMealPlanPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [showMacroCalculator, setShowMacroCalculator] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [formData, setFormData] = useState<MealPlanFormData>({
    startDate: new Date().toISOString().split('T')[0],
    days: 7,
    prompt: '',
    totalCalories: '',
    proteinGoal: '',
    carbsGoal: '',
    fatGoal: '',
    mealTypes: ['breakfast', 'lunch', 'dinner'],
    excludedIngredients: [],
    preferences: []
  });

  useEffect(() => {
    async function loadProfile() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          navigate('/auth');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        setProfile(data);

        // Pre-fill excluded ingredients from profile dietary restrictions
        if (data.dietary_restrictions?.length) {
          setFormData(prev => ({
            ...prev,
            excludedIngredients: data.dietary_restrictions
          }));
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      }
    }

    loadProfile();
  }, [navigate]);

  const updateFormData = (updates: Partial<MealPlanFormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleMacrosCalculated = (macros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }) => {
    updateFormData({
      totalCalories: macros.calories.toString(),
      proteinGoal: macros.protein.toString(),
      carbsGoal: macros.carbs.toString(),
      fatGoal: macros.fat.toString()
    });
    setShowMacroCalculator(false);
  };

  if (showMacroCalculator) {
    return (
      <div className="min-h-screen bg-cream py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <MacroCalculator
                profile={profile}
                onCalculate={handleMacrosCalculated}
                onCancel={() => setShowMacroCalculator(false)}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-3xl font-display font-bold text-charcoal">
                  Create Meal Plan
                </h1>
                <span className="text-deep-olive">
                  Step {step + 1} of 4
                </span>
              </div>
              <div className="w-full bg-cream rounded-full h-2">
                <div
                  className="bg-terracotta h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((step + 1) / 4) * 100}%` }}
                />
              </div>
            </div>

            {step === 0 ? (
              <div className="space-y-6">
                <div>
                  <label className="block text-lg font-medium mb-2">What kind of meal plan would you like?</label>
                  <p className="text-deep-olive mb-4">
                    Describe your goals, dietary preferences, or any specific requirements. Be as detailed as you'd like!
                  </p>
                  <textarea
                    value={formData.prompt}
                    onChange={(e) => updateFormData({ prompt: e.target.value })}
                    placeholder="Examples:&#10;• Weston A. Price Foundation meals for marathon training&#10;• Mediterranean diet with a focus on longevity&#10;• High-protein vegetarian meals for weightlifting&#10;• Traditional Japanese breakfast options&#10;• Kid-friendly meals that can be prepared in under 30 minutes"
                    className="w-full p-4 border rounded-lg h-48 resize-none"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Start Date</label>
                    <input
                      type="date"
                      value={formData.startDate}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => updateFormData({ startDate: e.target.value })}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Plan Duration</label>
                    <select
                      value={formData.days}
                      onChange={(e) => updateFormData({ days: parseInt(e.target.value) })}
                      className="w-full p-2 border rounded-lg"
                    >
                      <option value={3}>3 days {profile?.subscription_tier === 'free' && '(Free Plan)'}</option>
                      <option value={7} disabled={profile?.subscription_tier === 'free'}>
                        7 days {profile?.subscription_tier === 'free' && '(Premium Only)'}
                      </option>
                    </select>
                    {profile?.subscription_tier === 'free' && (
                      <p className="text-sm text-deep-olive mt-1">
                        Upgrade to Premium for 7-day meal plans
                      </p>
                    )}
                  </div>
                </div>

                <Button 
                  onClick={() => setStep(1)} 
                  className="w-full"
                  disabled={!formData.prompt.trim()}
                >
                  Next <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            ) : step === 1 ? (
              <PreferencesStep
                formData={formData}
                updateFormData={updateFormData}
                onNext={() => setStep(2)}
                onBack={() => setStep(0)}
              />
            ) : step === 2 ? (
              <NutritionGoalsStep
                formData={formData}
                updateFormData={updateFormData}
                onNext={() => setStep(3)}
                onBack={() => setStep(1)}
              />
            ) : (
              <ReviewStep
                formData={formData}
                onBack={() => setStep(2)}
                onSuccess={(mealPlanId) => navigate(`/meal-plan/${mealPlanId}`)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}