import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Save, AlertCircle, Crown, Loader2 } from 'lucide-react';
import { Button } from '../components/Button';
import { supabase } from '../lib/supabase';
import { createCheckoutSession } from '../lib/stripe';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

export function ProfileSettingsPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [formData, setFormData] = useState({
    height: '',
    height_unit: 'cm',
    weight: '',
    weight_unit: 'kg',
    activity_level: '',
    primary_goal: '',
    dietary_restrictions: [] as string[],
    cooking_for: '1'
  });

  useEffect(() => {
    async function loadProfile() {
      try {
        setLoading(true);
        setError(null);

        const { data: { session }, error: authError } = await supabase.auth.getSession();
        if (authError) throw authError;
        
        if (!session) {
          navigate('/auth');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (error) throw error;

        if (data) {
          setProfile(data);
          setFormData({
            height: data.height?.toString() || '',
            height_unit: data.height_unit || 'cm',
            weight: data.weight?.toString() || '',
            weight_unit: data.weight_unit || 'kg',
            activity_level: data.activity_level || '',
            primary_goal: data.primary_goal || '',
            dietary_restrictions: data.dietary_restrictions || [],
            cooking_for: data.cooking_for?.toString() || '1'
          });
        }
      } catch (error) {
        console.error('Error loading profile:', error);
        setError(error instanceof Error ? error.message : 'Failed to load profile');
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      const { data: { session }, error: authError } = await supabase.auth.getSession();
      if (authError) throw authError;
      if (!session) throw new Error('Not authenticated');

      const updates = {
        id: session.user.id,
        height: parseFloat(formData.height) || null,
        height_unit: formData.height_unit,
        weight: parseFloat(formData.weight) || null,
        weight_unit: formData.weight_unit,
        activity_level: formData.activity_level || null,
        primary_goal: formData.primary_goal || null,
        dietary_restrictions: formData.dietary_restrictions,
        cooking_for: parseInt(formData.cooking_for) || null,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('profiles')
        .upsert(updates);

      if (error) throw error;

      setError('Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      setError(error instanceof Error ? error.message : 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleUpgrade = async () => {
    try {
      setUpgrading(true);
      setError(null);

      const { data: { session }, error: authError } = await supabase.auth.getSession();
      if (authError) throw authError;
      if (!session) throw new Error('Please sign in to upgrade');

      await createCheckoutSession(session.user.id, 'monthly');
    } catch (error) {
      console.error('Error starting checkout:', error);
      setError(error instanceof Error ? error.message : 'Failed to start checkout');
    } finally {
      setUpgrading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-terracotta border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-deep-olive">Loading your profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h1 className="text-3xl font-display font-bold text-charcoal mb-8">Profile Settings</h1>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Information */}
              <div>
                <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Height</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={formData.height}
                        onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                        className="flex-1 p-2 border rounded-lg"
                        placeholder={formData.height_unit === 'cm' ? 'Height in cm' : 'Height in inches'}
                      />
                      <select
                        value={formData.height_unit}
                        onChange={(e) => setFormData(prev => ({ ...prev, height_unit: e.target.value as 'cm' | 'in' }))}
                        className="w-24 p-2 border rounded-lg"
                      >
                        <option value="cm">cm</option>
                        <option value="in">in</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Weight</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={formData.weight}
                        onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                        className="flex-1 p-2 border rounded-lg"
                        placeholder={formData.weight_unit === 'kg' ? 'Weight in kg' : 'Weight in pounds'}
                      />
                      <select
                        value={formData.weight_unit}
                        onChange={(e) => setFormData(prev => ({ ...prev, weight_unit: e.target.value as 'kg' | 'lb' }))}
                        className="w-24 p-2 border rounded-lg"
                      >
                        <option value="kg">kg</option>
                        <option value="lb">lb</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Preferences */}
              <div>
                <h2 className="text-xl font-semibold mb-4">Preferences</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Activity Level</label>
                    <select
                      value={formData.activity_level}
                      onChange={(e) => setFormData(prev => ({ ...prev, activity_level: e.target.value }))}
                      className="w-full p-2 border rounded-lg"
                    >
                      <option value="">Select activity level</option>
                      <option value="not_active">Not Very Active</option>
                      <option value="moderately_active">Moderately Active</option>
                      <option value="very_active">Very Active</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Primary Goal</label>
                    <select
                      value={formData.primary_goal}
                      onChange={(e) => setFormData(prev => ({ ...prev, primary_goal: e.target.value }))}
                      className="w-full p-2 border rounded-lg"
                    >
                      <option value="">Select your goal</option>
                      <option value="lose_weight">Lose Weight</option>
                      <option value="maintain_weight">Maintain Weight</option>
                      <option value="gain_muscle">Gain Muscle</option>
                      <option value="eat_healthier">Eat Healthier</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Dietary Restrictions */}
              <div>
                <h2 className="text-xl font-semibold mb-4">Dietary Restrictions</h2>
                <div className="space-y-2">
                  {['vegetarian', 'vegan', 'gluten-free', 'dairy-free'].map((restriction) => (
                    <label key={restriction} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.dietary_restrictions.includes(restriction)}
                        onChange={(e) => {
                          const updatedRestrictions = e.target.checked
                            ? [...formData.dietary_restrictions, restriction]
                            : formData.dietary_restrictions.filter(r => r !== restriction);
                          setFormData(prev => ({ ...prev, dietary_restrictions: updatedRestrictions }));
                        }}
                        className="mr-2"
                      />
                      {restriction.charAt(0).toUpperCase() + restriction.slice(1)}
                    </label>
                  ))}
                </div>
              </div>

              {/* Cooking Preferences */}
              <div>
                <h2 className="text-xl font-semibold mb-4">Cooking Preferences</h2>
                <div>
                  <label className="block text-sm font-medium mb-1">Cooking for how many people?</label>
                  <input
                    type="number"
                    min="1"
                    value={formData.cooking_for}
                    onChange={(e) => setFormData(prev => ({ ...prev, cooking_for: e.target.value }))}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
              </div>

              {error && (
                <div className={`p-4 rounded-lg flex items-center gap-2 ${
                  error.includes('success') ? 'bg-sage/20 text-forest-green' : 'bg-spice-red/20 text-spice-red'
                }`}>
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              )}

              <div className="flex justify-end">
                <Button type="submit" disabled={saving}>
                  <Save className="w-4 h-4 mr-2" />
                  {saving ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </form>
          </div>

          {profile?.subscription_tier === 'free' && (
            <div className="bg-white rounded-2xl p-8 shadow-lg mt-8">
              <div className="flex items-center gap-3 mb-6">
                <Crown className="w-8 h-8 text-warm-gold" />
                <h2 className="text-2xl font-display font-bold">Upgrade to Premium</h2>
              </div>
              <p className="text-deep-olive mb-6">
                Get access to weekly meal plans, smart shopping lists, and pantry management.
              </p>
              <Button 
                onClick={handleUpgrade}
                disabled={upgrading}
                className="w-full"
              >
                {upgrading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Upgrade Now - $25/month'
                )}
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}