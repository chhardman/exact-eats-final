import { 
  ChefHat, 
  ShoppingCart, 
  Package, 
  Brain, 
  Utensils, 
  Calendar,
  List,
  Store,
  Bell,
  Sparkles,
  Clock,
  DollarSign
} from 'lucide-react';
import { Button } from '../components/Button';

export function LearnMorePage() {
  return (
    <div className="bg-cream">
      {/* Hero Section */}
      <section className="bg-white section-padding">
        <div className="container mx-auto container-padding">
          <h1 className="text-5xl font-display font-bold text-center text-charcoal mb-8">
            Discover Exact Eats Features
          </h1>
          <p className="text-xl text-deep-olive text-center max-w-3xl mx-auto mb-12">
            Experience the future of meal planning with our AI-powered platform that makes cooking easier, 
            healthier, and more enjoyable than ever before.
          </p>
        </div>
      </section>

      {/* AI Meal Planning Section */}
      <section className="section-padding">
        <div className="container mx-auto container-padding">
          <div className="bg-white rounded-2xl p-8 md:p-12 mb-12">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <div className="flex items-center gap-4 mb-6">
                  <ChefHat className="w-10 h-10 text-terracotta" />
                  <h2 className="text-3xl font-display font-bold">AI Meal Planning</h2>
                </div>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <Brain className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Smart Recipe Suggestions</h3>
                      <p>Our AI learns your preferences and dietary needs to suggest perfect recipes.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Utensils className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Dietary Customization</h3>
                      <p>Accommodates allergies, preferences, and specific diet plans.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Calendar className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Flexible Planning</h3>
                      <p>Plan meals daily, weekly, or monthly with easy adjustments.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2">
                <img
                  src="https://images.unsplash.com/photo-1466637574441-749b8f19452f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="AI Meal Planning"
                  className="rounded-xl shadow-lg"
                />
              </div>
            </div>
          </div>

          {/* Smart Shopping List Section */}
          <div className="bg-white rounded-2xl p-8 md:p-12 mb-12">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2 order-2 md:order-1">
                <img
                  src="https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="Smart Shopping"
                  className="rounded-xl shadow-lg"
                />
              </div>
              <div className="md:w-1/2 order-1 md:order-2">
                <div className="flex items-center gap-4 mb-6">
                  <ShoppingCart className="w-10 h-10 text-terracotta" />
                  <h2 className="text-3xl font-display font-bold">Smart Shopping List</h2>
                </div>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <List className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Automatic List Generation</h3>
                      <p>Lists are created automatically based on your meal plans.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Store className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Store Mapping</h3>
                      <p>Organize items based on your local store's layout.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <DollarSign className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Budget Tracking</h3>
                      <p>Estimate grocery costs and track spending over time.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Pantry Management Section */}
          <div className="bg-white rounded-2xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <div className="flex items-center gap-4 mb-6">
                  <Package className="w-10 h-10 text-terracotta" />
                  <h2 className="text-3xl font-display font-bold">Pantry Management</h2>
                </div>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <Bell className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Expiration Alerts</h3>
                      <p>Get notified before ingredients expire to reduce food waste.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Sparkles className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Smart Suggestions</h3>
                      <p>Recipe suggestions based on what's in your pantry.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Clock className="w-6 h-6 text-terracotta mt-1" />
                    <div>
                      <h3 className="font-bold mb-2">Inventory Tracking</h3>
                      <p>Real-time tracking of your pantry inventory.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2">
                <img
                  src="https://images.unsplash.com/photo-1590311824865-bce1127a7c27?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="Pantry Management"
                  className="rounded-xl shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white section-padding">
        <div className="container mx-auto container-padding text-center">
          <h2 className="text-4xl font-display font-bold mb-6">
            Ready to Transform Your Meal Planning?
          </h2>
          <p className="text-xl text-deep-olive mb-8 max-w-2xl mx-auto">
            Join thousands of happy users who have made cooking and meal planning easier with Exact Eats.
          </p>
          <Button size="lg" className="mr-4">Get Started Free</Button>
        </div>
      </section>
    </div>
  );
}