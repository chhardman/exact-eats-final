export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          height: number | null
          height_unit: 'cm' | 'in' | null
          weight: number | null
          weight_unit: 'kg' | 'lb' | null
          activity_level: 'not_active' | 'moderately_active' | 'very_active' | null
          primary_goal: 'lose_weight' | 'maintain_weight' | 'gain_muscle' | 'eat_healthier' | null
          dietary_restrictions: string[] | null
          cooking_for: number | null
          subscription_tier: 'free' | 'premium' | null
          subscription_status: 'active' | 'inactive' | null
          meal_plans_generated_this_month: number
          shopping_list_optimizations_used: boolean
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          subscription_period_end: string | null
          subscription_cancel_at: string | null
        }
        Insert: {
          id: string
          created_at?: string
          updated_at?: string
          height?: number | null
          height_unit?: 'cm' | 'in' | null
          weight?: number | null
          weight_unit?: 'kg' | 'lb' | null
          activity_level?: 'not_active' | 'moderately_active' | 'very_active' | null
          primary_goal?: 'lose_weight' | 'maintain_weight' | 'gain_muscle' | 'eat_healthier' | null
          dietary_restrictions?: string[] | null
          cooking_for?: number | null
          subscription_tier?: 'free' | 'premium' | null
          subscription_status?: 'active' | 'inactive' | null
          meal_plans_generated_this_month?: number
          shopping_list_optimizations_used?: boolean
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          subscription_period_end?: string | null
          subscription_cancel_at?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          height?: number | null
          height_unit?: 'cm' | 'in' | null
          weight?: number | null
          weight_unit?: 'kg' | 'lb' | null
          activity_level?: 'not_active' | 'moderately_active' | 'very_active' | null
          primary_goal?: 'lose_weight' | 'maintain_weight' | 'gain_muscle' | 'eat_healthier' | null
          dietary_restrictions?: string[] | null
          cooking_for?: number | null
          subscription_tier?: 'free' | 'premium' | null
          subscription_status?: 'active' | 'inactive' | null
          meal_plans_generated_this_month?: number
          shopping_list_optimizations_used?: boolean
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          subscription_period_end?: string | null
          subscription_cancel_at?: string | null
        }
      }
      subscription_history: {
        Row: {
          id: string
          created_at: string
          user_id: string
          event_type: 'subscription_created' | 'subscription_updated' | 'subscription_cancelled' | 'subscription_renewed' | 'trial_started' | 'trial_ended'
          subscription_tier: 'free' | 'premium'
          billing_period: 'monthly' | 'annual' | null
          amount_paid: number | null
          stripe_event_id: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          user_id: string
          event_type: 'subscription_created' | 'subscription_updated' | 'subscription_cancelled' | 'subscription_renewed' | 'trial_started' | 'trial_ended'
          subscription_tier: 'free' | 'premium'
          billing_period?: 'monthly' | 'annual' | null
          amount_paid?: number | null
          stripe_event_id?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          user_id?: string
          event_type?: 'subscription_created' | 'subscription_updated' | 'subscription_cancelled' | 'subscription_renewed' | 'trial_started' | 'trial_ended'
          subscription_tier?: 'free' | 'premium'
          billing_period?: 'monthly' | 'annual' | null
          amount_paid?: number | null
          stripe_event_id?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      reset_monthly_meal_plan_count: {
        Args: Record<PropertyKey, never>
        Returns: void
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}