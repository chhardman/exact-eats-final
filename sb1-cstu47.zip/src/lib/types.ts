export interface GenerateMealPlanParams {
  days: number;
  prompt: string;
  totalCalories?: number;
  proteinGoal?: number;
  carbsGoal?: number;
  fatGoal?: number;
  mealTypes: string[];
  excludedIngredients: string[];
  preferences: string[];
}

export interface GeneratedRecipe {
  name: string;
  description: string;
  instructions: string[];
  ingredients: {
    item: string;
    amount: number;
    unit: string;
  }[];
  prep_time_minutes: number;
  cook_time_minutes: number;
  difficulty: 'easy' | 'medium' | 'hard';
  calories: number;
  protein_grams: number;
  carbs_grams: number;
  fat_grams: number;
  servings: number;
}