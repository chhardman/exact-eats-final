import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export async function createCheckoutSession(userId: string, billingPeriod: 'monthly' | 'annual') {
  try {
    const response = await fetch('/.netlify/functions/create-stripe-checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        billingPeriod,
        returnUrl: window.location.origin + '/dashboard',
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create checkout session');
    }

    const { url } = await response.json();
    if (!url) throw new Error('No checkout URL received');

    window.location.href = url;
  } catch (error) {
    console.error('Error creating checkout session:', error);
    throw error instanceof Error 
      ? error 
      : new Error('Failed to start checkout. Please try again.');
  }
}