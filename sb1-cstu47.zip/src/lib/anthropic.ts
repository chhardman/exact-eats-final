import { supabase } from './supabase';
import type { GenerateMealPlanParams, GeneratedRecipe } from './types';

interface ApiError {
  error: string;
}

export async function generateMealPlan(params: GenerateMealPlanParams): Promise<GeneratedRecipe[]> {
  try {
    const { data, error } = await supabase.functions.invoke('generate-meal-plan', {
      body: { params }
    });

    if (error) {
      throw new Error(error.message);
    }

    if ('error' in data) {
      throw new Error((data as ApiError).error);
    }

    return data as GeneratedRecipe[];
  } catch (error) {
    console.error('Error generating meal plan:', error);
    throw error instanceof Error ? error : new Error('Failed to generate meal plan. Please try again.');
  }
}

export async function regenerateMeal(
  originalRecipe: GeneratedRecipe,
  preferences: string[]
): Promise<GeneratedRecipe> {
  try {
    const { data, error } = await supabase.functions.invoke('regenerate-meal', {
      body: { originalRecipe, preferences }
    });

    if (error) {
      throw new Error(error.message);
    }

    if ('error' in data) {
      throw new Error((data as ApiError).error);
    }

    return data as GeneratedRecipe;
  } catch (error) {
    console.error('Error regenerating meal:', error);
    throw error instanceof Error ? error : new Error('Failed to regenerate meal. Please try again.');
  }
}