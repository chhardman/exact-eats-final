export const createMealPlanPrompt = (params: {
  days: number;
  prompt: string;
  totalCalories?: number;
  proteinGoal?: number;
  carbsGoal?: number;
  fatGoal?: number;
  mealTypes: string[];
  excludedIngredients: string[];
  preferences: string[];
}) => `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

Each recipe must include:
1. Name (unique and descriptive)
2. Brief description (2-3 sentences)
3. List of ingredients with precise measurements
4. Step-by-step instructions (clear and concise)
5. Preparation time (realistic estimate)
6. Cooking time (realistic estimate)
7. Difficulty level (easy/medium/hard)
8. Nutritional information per serving
9. Number of servings (default to 4)

Format the response as a JSON array of recipes. Each recipe must follow this exact structure:
{
  "name": string,
  "description": string,
  "instructions": string[],
  "ingredients": [
    {
      "item": string,
      "amount": number,
      "unit": string
    }
  ],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number,
  "advance_prep": {
    "required": boolean,
    "time_required": string,
    "instructions": string[]
  }
}`;