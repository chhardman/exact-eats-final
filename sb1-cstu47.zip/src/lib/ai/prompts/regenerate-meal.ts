export const createRegenerateMealPrompt = (originalRecipe: any, preferences: string[]) => `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(originalRecipe, null, 2)}

Additional Preferences: ${preferences?.join(', ') || 'None'}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people

Format the response as a JSON object with this exact structure:
{
  "name": string,
  "description": string,
  "instructions": string[],
  "ingredients": [
    {
      "item": string,
      "amount": number,
      "unit": string
    }
  ],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number,
  "advance_prep": {
    "required": boolean,
    "time_required": string,
    "instructions": string[]
  }
}`;