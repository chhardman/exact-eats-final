export function createShoppingListPrompt(items: any[]) {
  return `You are a shopping list optimization expert. Analyze and optimize this shopping list by:
1. Combining **identical** items and adjusting quantities
2. Converting to practical shopping units
3. Adjusting quantities to match standard package sizes
4. Grouping by category

Original Shopping List:
${items.map(item => `${item.amount} ${item.unit} ${item.item}`).join('\n')}

Return a JSON object with this EXACT structure:
{
  "optimizedList": [
    {
      "item": string,      // Name of the item
      "amount": number,    // Numeric quantity
      "unit": string,      // Unit of measurement
      "category": string   // One of: "produce", "meat", "dairy", "frozen", "pantry", "spices", "other"
    }
  ]
}

Guidelines:
1. Combine **identical** items (e.g., "2 cups flour" + "1 cup flour" = "3 cups flour")
   - **Do not** combine items that are different, even if they are similar (e.g., "carrots" and "sweet potatoes" should remain separate)

2. Convert to practical shopping units:
   Liquids:
   - Use standard container sizes (e.g., gallon, half-gallon, quart)
   - Round up to the next standard size if necessary
   - For example, if total milk needed is 2 cups, suggest buying 1 quart of milk

   Dry Goods:
   - Use standard package sizes (e.g., 5 lb bag of flour)
   - Round up to the next available package size
   - For example, if total flour needed is 0.25 lbs, suggest buying 5 lbs of flour

   Produce:
   - Use "each" or "piece" for whole items
   - Use lb for bulk items
   - Use "bunch" for bundled items

   Meat:
   - Use lb for raw meat
   - Use "package" for pre-packaged meat

   Dairy:
   - Use standard container sizes for milk (gallon, half-gallon, quart)
   - Use lb for cheese
   - Use "dozen" for eggs
   - Use "container" for yogurt/sour cream

3. Adjust quantities to match standard package sizes:
   - For items sold in standard packages, adjust quantities to match these sizes
   - Always round up to ensure sufficient quantity
   - Examples:
     - If total required sugar is 1.5 lbs, and sugar is sold in 2 lb bags, set amount to 2 lbs
     - If total required eggs are 8, and eggs are sold by the dozen, set amount to 1 dozen

4. Round quantities to practical amounts:
   - Round up to the next standard package size for packaged goods
   - Round to the nearest 0.25 for pounds
   - Round to whole numbers for countable items
   - Use common fractions (1/2, 1/3, 1/4) for smaller amounts

5. Group by logical categories

Example response:
{
  "optimizedList": [
    {
      "item": "whole milk",
      "amount": 1,
      "unit": "gallon",
      "category": "dairy"
    },
    {
      "item": "all-purpose flour",
      "amount": 5,
      "unit": "lb",
      "category": "pantry"
    },
    {
      "item": "large eggs",
      "amount": 1,
      "unit": "dozen",
      "category": "dairy"
    },
    {
      "item": "carrots",
      "amount": 2,
      "unit": "each",
      "category": "produce"
    },
    {
      "item": "sweet potato",
      "amount": 1,
      "unit": "each",
      "category": "produce"
    }
  ]
}

IMPORTANT: 
- Response must be valid JSON
- All fields must match the exact types specified
- No additional fields or commentary
- Keep response concise and focused
- Always use practical, shoppable units
- Adjust quantities to match common package sizes
- Round quantities to reasonable amounts
- **Do not combine different items, even if they are similar**

`;
}
