import type { MealPlanRequest, RegenerateMealRequest } from './types';

export function createMealPlanPrompt(params: MealPlanRequest): string {
  return `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

For each meal, provide:
1. Recipe name
2. Brief description
3. List of ingredients with precise measurements
4. Step-by-step instructions
5. Preparation time
6. Cooking time
7. Difficulty level (easy/medium/hard)
8. Nutritional information (calories, protein, carbs, fat)
9. Number of servings

Format the response as a JSON array of recipes. Each recipe must follow this structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}

Ensure all measurements are precise and nutritional information is accurate.`;
}

export function createRegenerateMealPrompt(params: RegenerateMealRequest): string {
  return `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(params.originalRecipe, null, 2)}

Additional Preferences: ${params.preferences.join(', ')}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people

Format the response as a single JSON recipe object following this structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}

The response must be a valid JSON object.`;
}