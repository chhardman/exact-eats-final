import { createShoppingListPrompt } from './prompts/shopping-list';
import { createMealPlanPrompt } from './prompts/meal-plan';
import { createRegenerateMealPrompt } from './prompts/regenerate-meal';
import OpenAI from 'openai';
import type { GenerateMealPlanParams, Recipe } from './types';
import type { ShoppingListItem } from '../types/shopping';

const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});

interface OptimizedListResponse {
  optimizedList: Array<{
    item: string;
    amount: number;
    unit: string;
    category: string;
  }>;
}

export async function optimizeShoppingList(items: ShoppingListItem[]): Promise<ShoppingListItem[]> {
  try {
    if (!items?.length) {
      throw new Error('No items provided to optimize');
    }

    console.log('Original items:', items);

    const response = await openai.chat.completions.create({
      model: "gpt-4-0125-preview",
      messages: [
        {
          role: "system",
          content: createShoppingListPrompt(items)
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
      max_tokens: 2000,
      seed: 12345
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('Empty response from AI');
    }

    console.log('AI response:', content);

    let parsedResponse: OptimizedListResponse;
    try {
      parsedResponse = JSON.parse(content);
    } catch (error) {
      console.error('Failed to parse AI response:', content);
      throw new Error('Invalid JSON response from AI');
    }

    if (!parsedResponse?.optimizedList?.length) {
      throw new Error('Invalid response format from AI');
    }

    console.log('Parsed response:', parsedResponse);

    // Transform the response
    const optimizedList = parsedResponse.optimizedList.map(item => ({
      id: crypto.randomUUID(),
      shopping_list_id: items[0].shopping_list_id,
      item: item.item,
      amount: item.amount,
      unit: item.unit,
      category: item.category,
      checked: false
    }));

    console.log('Final optimized list:', optimizedList);
    return optimizedList;

  } catch (error) {
    console.error('Error optimizing shopping list:', error);
    throw error instanceof Error 
      ? new Error(`Failed to optimize shopping list: ${error.message}`)
      : new Error('Failed to optimize shopping list');
  }
}

export async function generateMealPlan(params: GenerateMealPlanParams): Promise<Recipe[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4-0125-preview",
      messages: [
        {
          role: "system",
          content: createMealPlanPrompt(params)
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 4000
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('Empty response from AI');
    }

    const parsedResponse = JSON.parse(content);
    if (!parsedResponse?.recipes || !Array.isArray(parsedResponse.recipes)) {
      throw new Error('Invalid response format from AI');
    }

    return parsedResponse.recipes;
  } catch (error) {
    console.error('Error generating meal plan:', error);
    throw error instanceof Error ? error : new Error('Failed to generate meal plan');
  }
}

export async function regenerateMeal(originalRecipe: Recipe, preferences: string[]): Promise<Recipe> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4-0125-preview",
      messages: [
        {
          role: "system",
          content: createRegenerateMealPrompt(originalRecipe, preferences)
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('Empty response from AI');
    }

    const parsedResponse = JSON.parse(content);
    if (!parsedResponse?.recipe) {
      throw new Error('Invalid response format from AI');
    }

    return parsedResponse.recipe;
  } catch (error) {
    console.error('Error regenerating meal:', error);
    throw error instanceof Error ? error : new Error('Failed to regenerate meal');
  }
}