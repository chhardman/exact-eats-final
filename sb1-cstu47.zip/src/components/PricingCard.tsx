import { Check } from 'lucide-react';
import { Button } from './Button';
import { cn } from '../utils/cn';

interface PricingCardProps {
  title: string;
  price: string;
  features: string[];
  isPopular?: boolean;
  onGetStarted?: () => void;
}

export function PricingCard({ title, price, features, isPopular, onGetStarted }: PricingCardProps) {
  return (
    <div className={cn(
      "rounded-2xl p-8 bg-white shadow-lg transition-transform hover:scale-105",
      isPopular && "border-2 border-terracotta relative"
    )}>
      {isPopular && (
        <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-terracotta text-white px-4 py-1 rounded-full text-sm">
          Most Popular
        </span>
      )}
      <h3 className="text-2xl font-display font-bold text-charcoal">{title}</h3>
      <div className="mt-4 mb-6">
        <span className="text-4xl font-bold">{price}</span>
        {price !== "Free" && <span className="text-gray-600">/month</span>}
      </div>
      <ul className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-3">
            <Check className="w-5 h-5 text-terracotta" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      <Button 
        variant={isPopular ? 'primary' : 'secondary'} 
        className="w-full"
        onClick={onGetStarted}
      >
        Get Started
      </Button>
    </div>
  );
}