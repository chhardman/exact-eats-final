import { useState } from 'react';
import { Clock, ChefHat, ArrowUpRight, ArrowLeftRight } from 'lucide-react';
import type { MealPlanDay } from '../../types/meal-plan';

interface MealCardProps {
  meal: MealPlanDay['meals'][0];
  isSelected: boolean;
  onClick: () => void;
  swapMode?: boolean;
  isSwapSource?: boolean;
  isSwapTarget?: boolean;
}

export function MealCard({ 
  meal, 
  isSelected, 
  onClick,
  swapMode,
  isSwapSource,
  isSwapTarget 
}: MealCardProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left rounded-lg p-6 transition-all hover:shadow-md group ${
        isSelected ? 'bg-white shadow-md' : 'bg-white/50 hover:bg-white'
      } ${isSwapSource ? 'ring-2 ring-terracotta' : ''} 
      ${isSwapTarget ? 'ring-2 ring-terracotta/50 hover:ring-terracotta' : ''}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="font-semibold mb-1 group-hover:text-terracotta">
            {meal.recipe.name}
          </h3>
          <p className="text-sm text-deep-olive mb-3">{meal.type}</p>
        </div>
        {swapMode ? (
          <ArrowLeftRight className={`w-4 h-4 ${
            isSwapSource ? 'text-terracotta' : 'text-terracotta/50'
          }`} />
        ) : (
          <ArrowUpRight className="w-4 h-4 text-terracotta opacity-0 group-hover:opacity-100 transition-opacity" />
        )}
      </div>
      
      <div className="flex items-center gap-4 text-sm text-deep-olive mb-3">
        <div className="flex items-center">
          <Clock className="w-4 h-4 mr-1" />
          {meal.recipe.prep_time_minutes + meal.recipe.cook_time_minutes}m
        </div>
        <div className="flex items-center">
          <ChefHat className="w-4 h-4 mr-1" />
          {meal.recipe.difficulty}
        </div>
      </div>

      <div className="text-sm">
        <div className="mb-1">Calories: {meal.recipe.calories * meal.servings}</div>
        <div className="grid grid-cols-3 gap-2">
          <div>P: {meal.recipe.protein_grams * meal.servings}g</div>
          <div>C: {meal.recipe.carbs_grams * meal.servings}g</div>
          <div>F: {meal.recipe.fat_grams * meal.servings}g</div>
        </div>
      </div>
    </button>
  );
}