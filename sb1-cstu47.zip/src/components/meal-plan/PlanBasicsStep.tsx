import { Button } from '../Button';
import { ChevronRight } from 'lucide-react';

interface PlanBasicsStepProps {
  formData: {
    startDate: string;
    days: number;
  };
  updateFormData: (updates: Partial<typeof formData>) => void;
  onNext: () => void;
}

export function PlanBasicsStep({ formData, updateFormData, onNext }: PlanBasicsStepProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-1">Start Date</label>
        <input
          type="date"
          value={formData.startDate}
          min={new Date().toISOString().split('T')[0]}
          onChange={(e) => updateFormData({ startDate: e.target.value })}
          className="w-full p-2 border rounded-lg"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Number of Days</label>
        <select
          value={formData.days}
          onChange={(e) => updateFormData({ days: parseInt(e.target.value) })}
          className="w-full p-2 border rounded-lg"
        >
          <option value={3}>3 days</option>
          <option value={5}>5 days</option>
          <option value={7}>7 days</option>
        </select>
      </div>

      <Button onClick={onNext} className="w-full">
        Next <ChevronRight className="w-4 h-4 ml-2" />
      </Button>
    </div>
  );
}