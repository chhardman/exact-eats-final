import { useState } from 'react';
import { Button } from '../Button';
import { ChevronLeft, ChevronRight, Calculator } from 'lucide-react';
import { MacroCalculator } from './MacroCalculator';

interface NutritionGoalsStepProps {
  formData: {
    totalCalories: string;
    proteinGoal: string;
    carbsGoal: string;
    fatGoal: string;
  };
  updateFormData: (updates: Partial<typeof formData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export function NutritionGoalsStep({ 
  formData, 
  updateFormData, 
  onNext, 
  onBack 
}: NutritionGoalsStepProps) {
  const [showCalculator, setShowCalculator] = useState(false);

  const handleMacrosCalculated = (macros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }) => {
    updateFormData({
      totalCalories: macros.calories.toString(),
      proteinGoal: macros.protein.toString(),
      carbsGoal: macros.carbs.toString(),
      fatGoal: macros.fat.toString()
    });
    setShowCalculator(false);
  };

  if (showCalculator) {
    return (
      <MacroCalculator
        onCalculate={handleMacrosCalculated}
        onCancel={() => setShowCalculator(false)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <label className="block text-sm font-medium">Daily Calories</label>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowCalculator(true)}
          >
            <Calculator className="w-4 h-4 mr-2" />
            Calculate
          </Button>
        </div>
        <input
          type="number"
          value={formData.totalCalories}
          onChange={(e) => updateFormData({ totalCalories: e.target.value })}
          placeholder="e.g., 2000"
          className="w-full p-2 border rounded-lg"
        />
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Protein (g)</label>
          <input
            type="number"
            value={formData.proteinGoal}
            onChange={(e) => updateFormData({ proteinGoal: e.target.value })}
            placeholder="e.g., 150"
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Carbs (g)</label>
          <input
            type="number"
            value={formData.carbsGoal}
            onChange={(e) => updateFormData({ carbsGoal: e.target.value })}
            placeholder="e.g., 200"
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Fat (g)</label>
          <input
            type="number"
            value={formData.fatGoal}
            onChange={(e) => updateFormData({ fatGoal: e.target.value })}
            placeholder="e.g., 65"
            className="w-full p-2 border rounded-lg"
          />
        </div>
      </div>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={onBack}>
          <ChevronLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Next <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}