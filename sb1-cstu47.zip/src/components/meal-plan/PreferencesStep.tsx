import { useState } from 'react';
import { Button } from '../Button';
import { ChevronLeft, ChevronRight, Plus, X } from 'lucide-react';

interface PreferencesStepProps {
  formData: {
    mealTypes: string[];
    excludedIngredients: string[];
    preferences: string[];
  };
  updateFormData: (updates: Partial<typeof formData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export function PreferencesStep({ 
  formData, 
  updateFormData, 
  onNext, 
  onBack 
}: PreferencesStepProps) {
  const [newMealType, setNewMealType] = useState('');
  const [newIngredient, setNewIngredient] = useState('');
  const [newPreference, setNewPreference] = useState('');

  const addMealType = () => {
    if (newMealType && !formData.mealTypes.includes(newMealType)) {
      updateFormData({
        mealTypes: [...formData.mealTypes, newMealType]
      });
      setNewMealType('');
    }
  };

  const removeMealType = (type: string) => {
    updateFormData({
      mealTypes: formData.mealTypes.filter(t => t !== type)
    });
  };

  const addExcludedIngredient = () => {
    if (newIngredient && !formData.excludedIngredients.includes(newIngredient)) {
      updateFormData({
        excludedIngredients: [...formData.excludedIngredients, newIngredient]
      });
      setNewIngredient('');
    }
  };

  const removeExcludedIngredient = (ingredient: string) => {
    updateFormData({
      excludedIngredients: formData.excludedIngredients.filter(i => i !== ingredient)
    });
  };

  const addPreference = () => {
    if (newPreference && !formData.preferences.includes(newPreference)) {
      updateFormData({
        preferences: [...formData.preferences, newPreference]
      });
      setNewPreference('');
    }
  };

  const removePreference = (pref: string) => {
    updateFormData({
      preferences: formData.preferences.filter(p => p !== pref)
    });
  };

  return (
    <div className="space-y-8">
      {/* Meal Types */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Meal Types</h3>
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMealType}
              onChange={(e) => setNewMealType(e.target.value)}
              placeholder="Add meal type (e.g., snack, dessert)"
              className="flex-1 p-2 border rounded-lg"
            />
            <Button onClick={addMealType}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.mealTypes.map((type) => (
              <span
                key={type}
                className="bg-cream px-3 py-1 rounded-full text-sm flex items-center gap-2"
              >
                {type}
                <button
                  onClick={() => removeMealType(type)}
                  className="text-terracotta hover:text-burnt-orange"
                >
                  <X className="w-4 h-4" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Excluded Ingredients */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Excluded Ingredients</h3>
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newIngredient}
              onChange={(e) => setNewIngredient(e.target.value)}
              placeholder="Add ingredient to exclude"
              className="flex-1 p-2 border rounded-lg"
            />
            <Button onClick={addExcludedIngredient}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.excludedIngredients.map((ingredient) => (
              <span
                key={ingredient}
                className="bg-cream px-3 py-1 rounded-full text-sm flex items-center gap-2"
              >
                {ingredient}
                <button
                  onClick={() => removeExcludedIngredient(ingredient)}
                  className="text-terracotta hover:text-burnt-orange"
                >
                  <X className="w-4 h-4" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Additional Preferences */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Additional Preferences</h3>
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newPreference}
              onChange={(e) => setNewPreference(e.target.value)}
              placeholder="Add preference (e.g., low-carb, spicy)"
              className="flex-1 p-2 border rounded-lg"
            />
            <Button onClick={addPreference}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.preferences.map((pref) => (
              <span
                key={pref}
                className="bg-cream px-3 py-1 rounded-full text-sm flex items-center gap-2"
              >
                {pref}
                <button
                  onClick={() => removePreference(pref)}
                  className="text-terracotta hover:text-burnt-orange"
                >
                  <X className="w-4 h-4" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={onBack}>
          <ChevronLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Next <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}