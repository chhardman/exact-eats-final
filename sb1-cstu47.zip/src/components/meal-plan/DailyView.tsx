import { useState } from 'react';
import { Clock, ChefHat, ListOrdered, ListChecks } from 'lucide-react';
import { Button } from '../Button';
import type { MealPlanDay } from '../../types/meal-plan';

interface DailyViewProps {
  day: MealPlanDay;
  onServingsChange: (mealId: string, servings: number) => Promise<void>;
}

export function DailyView({ day, onServingsChange }: DailyViewProps) {
  const [viewMode, setViewMode] = useState<'instructions' | 'ingredients'>('instructions');

  return (
    <div className="space-y-8">
      {day.meals.map((meal) => (
        <div
          key={meal.id}
          className="bg-white rounded-2xl p-6 shadow-lg"
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold mb-1">{meal.recipe.name}</h3>
              <p className="text-deep-olive">{meal.type}</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center text-deep-olive">
                  <Clock className="w-4 h-4 mr-1" />
                  {meal.recipe.prep_time_minutes + meal.recipe.cook_time_minutes} min
                </div>
                <div className="flex items-center text-deep-olive">
                  <ChefHat className="w-4 h-4 mr-1" />
                  {meal.recipe.difficulty}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Servings</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onServingsChange(meal.id, meal.servings - 1)}
                      disabled={meal.servings <= 1}
                      className="w-8 h-8 rounded-full bg-cream flex items-center justify-center disabled:opacity-50"
                    >
                      -
                    </button>
                    <span className="w-8 text-center">{meal.servings}</span>
                    <button
                      onClick={() => onServingsChange(meal.id, meal.servings + 1)}
                      className="w-8 h-8 rounded-full bg-cream flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 bg-cream rounded-lg p-4">
                  <div>
                    <div className="text-sm text-deep-olive">Per Serving</div>
                    <div>Calories: {meal.recipe.calories}</div>
                    <div>Protein: {meal.recipe.protein_grams}g</div>
                    <div>Carbs: {meal.recipe.carbs_grams}g</div>
                    <div>Fat: {meal.recipe.fat_grams}g</div>
                  </div>
                  <div>
                    <div className="text-sm text-deep-olive">Total</div>
                    <div>Calories: {meal.recipe.calories * meal.servings}</div>
                    <div>Protein: {meal.recipe.protein_grams * meal.servings}g</div>
                    <div>Carbs: {meal.recipe.carbs_grams * meal.servings}g</div>
                    <div>Fat: {meal.recipe.fat_grams * meal.servings}g</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">
                  {viewMode === 'instructions' ? 'Instructions' : 'Ingredients'}
                </h4>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setViewMode(prev => 
                    prev === 'instructions' ? 'ingredients' : 'instructions'
                  )}
                >
                  {viewMode === 'instructions' ? (
                    <>
                      <ListChecks className="w-4 h-4 mr-2" />
                      Show Ingredients
                    </>
                  ) : (
                    <>
                      <ListOrdered className="w-4 h-4 mr-2" />
                      Show Instructions
                    </>
                  )}
                </Button>
              </div>

              {viewMode === 'instructions' ? (
                <ol className="list-decimal list-inside space-y-2">
                  {meal.recipe.instructions.map((step, index) => (
                    <li key={index} className="pl-2">{step}</li>
                  ))}
                </ol>
              ) : (
                <ul className="space-y-2">
                  {meal.recipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-baseline gap-2">
                      <span className="font-semibold whitespace-nowrap">
                        {ingredient.amount * meal.servings} {ingredient.unit}
                      </span>
                      <span>{ingredient.item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      ))}

      <div className="bg-cream rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4">Daily Totals</h3>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <div className="text-deep-olive mb-1">Calories</div>
            <div className="text-2xl font-semibold">{day.total_calories}</div>
          </div>
          <div>
            <div className="text-deep-olive mb-1">Protein</div>
            <div className="text-2xl font-semibold">{day.total_protein}g</div>
          </div>
          <div>
            <div className="text-deep-olive mb-1">Carbs</div>
            <div className="text-2xl font-semibold">{day.total_carbs}g</div>
          </div>
          <div>
            <div className="text-deep-olive mb-1">Fat</div>
            <div className="text-2xl font-semibold">{day.total_fat}g</div>
          </div>
        </div>
      </div>
    </div>
  );
}