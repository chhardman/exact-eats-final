import { useState, useEffect } from 'react';
import { X, ShoppingCart, Check, Share2, Download, Save } from 'lucide-react';
import { Button } from '../Button';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import type { MealPlan } from '../../types/meal-plan';
import type { Category, ShoppingListItem } from '../../types/shopping';

interface ShoppingListProps {
  mealPlan: MealPlan;
  onClose: () => void;
}

export function ShoppingList({ mealPlan, onClose }: ShoppingListProps) {
  const navigate = useNavigate();
  const [groupedIngredients, setGroupedIngredients] = useState<Record<string, ShoppingListItem[]>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // Helper function to determine category
    const getCategory = (item: string): Category => {
      const lowerItem = item.toLowerCase();
      
      if (/fresh|vegetable|fruit|herb|lettuce|tomato|onion|potato/i.test(lowerItem)) {
        return 'produce';
      }
      if (/meat|chicken|beef|pork|fish|salmon/i.test(lowerItem)) {
        return 'meat';
      }
      if (/milk|cheese|yogurt|cream|butter/i.test(lowerItem)) {
        return 'dairy';
      }
      if (/frozen/i.test(lowerItem)) {
        return 'frozen';
      }
      if (/spice|herb|seasoning/i.test(lowerItem)) {
        return 'spices';
      }
      if (/flour|sugar|oil|pasta|rice|bean|sauce/i.test(lowerItem)) {
        return 'pantry';
      }
      return 'other';
    };

    // Group and combine ingredients
    const groups: Record<string, ShoppingListItem[]> = {};

    mealPlan.days.forEach(day => {
      day.meals.forEach(meal => {
        meal.recipe.ingredients.forEach(ingredient => {
          const category = getCategory(ingredient.item);
          
          if (!groups[category]) {
            groups[category] = [];
          }

          const existingItem = groups[category].find(
            i => i.item === ingredient.item && i.unit === ingredient.unit
          );

          if (existingItem) {
            existingItem.amount += ingredient.amount * meal.servings;
          } else {
            groups[category].push({
              id: crypto.randomUUID(),
              shopping_list_id: '',
              item: ingredient.item,
              amount: ingredient.amount * meal.servings,
              unit: ingredient.unit,
              category,
              checked: false,
              recipe_id: meal.recipe.id,
              meal_plan_item_id: meal.id
            });
          }
        });
      });
    });

    setGroupedIngredients(groups);
  }, [mealPlan]);

  const saveToShoppingList = async () => {
    try {
      setSaving(true);

      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('You must be logged in to save a shopping list');
      }

      // Create shopping list
      const { data: shoppingList, error: listError } = await supabase
        .from('shopping_lists')
        .insert({
          user_id: user.id,
          meal_plan_id: mealPlan.id,
          name: `Meal Plan - ${new Date(mealPlan.start_date).toLocaleDateString()}`,
          notes: `Shopping list for ${mealPlan.days.length}-day meal plan`
        })
        .select()
        .single();

      if (listError) throw listError;

      // Add items to shopping list
      const items = Object.values(groupedIngredients)
        .flat()
        .map(item => ({
          shopping_list_id: shoppingList.id,
          item: item.item,
          amount: item.amount,
          unit: item.unit,
          category: item.category,
          checked: item.checked,
          recipe_id: item.recipe_id,
          meal_plan_item_id: item.meal_plan_item_id
        }));

      const { error: itemsError } = await supabase
        .from('shopping_list_items')
        .insert(items);

      if (itemsError) throw itemsError;

      // Navigate to shopping list page
      navigate('/shopping-list');
    } catch (error) {
      console.error('Error saving shopping list:', error);
      alert(error instanceof Error ? error.message : 'Failed to save shopping list');
    } finally {
      setSaving(false);
      onClose();
    }
  };

  const handleShare = async () => {
    try {
      const text = Object.entries(groupedIngredients)
        .map(([category, items]) => (
          `${category.toUpperCase()}\n${items
            .map(item => `- ${item.amount} ${item.unit} ${item.item}`)
            .join('\n')}`
        ))
        .join('\n\n');

      await navigator.share({
        title: 'Shopping List',
        text
      });
    } catch (error) {
      console.error('Error sharing list:', error);
    }
  };

  const handleDownload = () => {
    const text = Object.entries(groupedIngredients)
      .map(([category, items]) => (
        `${category.toUpperCase()}\n${items
          .map(item => `- ${item.amount} ${item.unit} ${item.item}`)
          .join('\n')}`
      ))
      .join('\n\n');

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'shopping-list.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-charcoal/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShoppingCart className="w-6 h-6 text-terracotta" />
              <h2 className="text-2xl font-display font-bold">Shopping List</h2>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4" />
              </Button>
              <Button variant="secondary" size="sm" onClick={handleDownload}>
                <Download className="w-4 h-4" />
              </Button>
              <button onClick={onClose}>
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {Object.entries(groupedIngredients).map(([category, items]) => (
            <div key={category} className="mb-8 last:mb-0">
              <h3 className="text-lg font-semibold capitalize mb-4">
                {category}
              </h3>
              <div className="space-y-2">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-cream"
                  >
                    <button
                      onClick={() => {
                        setGroupedIngredients(prev => ({
                          ...prev,
                          [category]: prev[category].map(i => 
                            i.id === item.id ? { ...i, checked: !i.checked } : i
                          )
                        }));
                      }}
                      className={`w-6 h-6 rounded border flex items-center justify-center transition-colors ${
                        item.checked
                          ? 'bg-terracotta border-terracotta text-white'
                          : 'border-deep-olive'
                      }`}
                    >
                      {item.checked && <Check className="w-4 h-4" />}
                    </button>
                    <span className={item.checked ? 'line-through text-deep-olive' : ''}>
                      {item.amount} {item.unit} {item.item}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 border-t flex gap-4">
          <Button variant="secondary" onClick={onClose} className="flex-1">
            Close
          </Button>
          <Button 
            onClick={saveToShoppingList} 
            className="flex-1"
            disabled={saving}
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save to Shopping List'}
          </Button>
        </div>
      </div>
    </div>
  );
}