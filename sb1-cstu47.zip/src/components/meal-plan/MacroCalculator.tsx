import { useState, useEffect } from 'react';
import { Button } from '../Button';
import { X } from 'lucide-react';
import type { Database } from '../../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface MacroCalculatorProps {
  profile: Profile | null;
  onCalculate: (macros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }) => void;
  onCancel: () => void;
}

export function MacroCalculator({ profile, onCalculate, onCancel }: MacroCalculatorProps) {
  const [formData, setFormData] = useState({
    age: '',
    height: profile?.height?.toString() || '',
    heightUnit: profile?.height_unit || 'cm',
    weight: profile?.weight?.toString() || '',
    weightUnit: profile?.weight_unit || 'kg',
    activityLevel: profile?.activity_level || '',
    goal: profile?.primary_goal || '',
    gender: 'male'
  });

  useEffect(() => {
    if (profile) {
      setFormData(prev => ({
        ...prev,
        height: profile.height?.toString() || '',
        heightUnit: profile.height_unit || 'cm',
        weight: profile.weight?.toString() || '',
        weightUnit: profile.weight_unit || 'kg',
        activityLevel: profile.activity_level || '',
        goal: profile.primary_goal || ''
      }));
    }
  }, [profile]);

  const calculateMacros = () => {
    // Convert measurements to metric
    const heightInCm = formData.heightUnit === 'in' 
      ? parseFloat(formData.height) * 2.54
      : parseFloat(formData.height);
    
    const weightInKg = formData.weightUnit === 'lb' 
      ? parseFloat(formData.weight) * 0.453592
      : parseFloat(formData.weight);

    const age = parseInt(formData.age);

    // Calculate BMR using Harris-Benedict Equation
    let bmr;
    if (formData.gender === 'male') {
      bmr = 66.47 + (13.75 * weightInKg) + (5.003 * heightInCm) - (6.755 * age);
    } else {
      bmr = 655.1 + (9.563 * weightInKg) + (1.850 * heightInCm) - (4.676 * age);
    }

    // Activity multipliers
    const activityMultipliers = {
      not_active: 1.2,
      moderately_active: 1.55,
      very_active: 1.725
    };

    // Calculate TDEE
    const activityMultiplier = activityMultipliers[formData.activityLevel as keyof typeof activityMultipliers] || 1.2;
    let calories = Math.round(bmr * activityMultiplier);

    // Goal adjustments
    const goalAdjustments = {
      lose_weight: -500,
      maintain_weight: 0,
      gain_muscle: 300,
      eat_healthier: 0
    };

    calories += goalAdjustments[formData.goal as keyof typeof goalAdjustments] || 0;

    // Calculate protein based on body weight
    let protein: number;
    switch (formData.goal) {
      case 'lose_weight':
        // Higher protein while cutting (2.2-2.4g/kg)
        protein = Math.round(weightInKg * 2.3);
        break;
      case 'gain_muscle':
        // Moderate-high protein for muscle gain (1.8-2.2g/kg)
        protein = Math.round(weightInKg * 2.0);
        break;
      default:
        // Maintenance protein (1.6-1.8g/kg)
        protein = Math.round(weightInKg * 1.7);
    }

    // Calculate remaining calories for carbs and fats
    const remainingCalories = calories - (protein * 4);

    // Distribute remaining calories between carbs and fats based on goal
    let fatCalories: number;
    switch (formData.goal) {
      case 'lose_weight':
        // Higher fats for satiety while cutting (30-35% of remaining)
        fatCalories = remainingCalories * 0.35;
        break;
      case 'gain_muscle':
        // Lower fats while bulking (20-25% of remaining)
        fatCalories = remainingCalories * 0.25;
        break;
      default:
        // Balanced fats for maintenance (25-30% of remaining)
        fatCalories = remainingCalories * 0.3;
    }

    const fat = Math.round(fatCalories / 9);
    const carbs = Math.round((remainingCalories - fatCalories) / 4);

    onCalculate({ calories, protein, carbs, fat });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold">Calculate Your Daily Targets</h3>
        <button onClick={onCancel}>
          <X className="w-5 h-5" />
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Gender</label>
        <div className="flex gap-4">
          <label className="flex items-center">
            <input
              type="radio"
              value="male"
              checked={formData.gender === 'male'}
              onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
              className="mr-2"
            />
            Male
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              value="female"
              checked={formData.gender === 'female'}
              onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
              className="mr-2"
            />
            Female
          </label>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Age</label>
        <input
          type="number"
          value={formData.age}
          onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
          className="w-full p-2 border rounded-lg"
          placeholder="Enter your age"
          min="18"
          max="120"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Height</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={formData.height}
            onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
            className="flex-1 p-2 border rounded-lg"
            placeholder={formData.heightUnit === 'cm' ? 'Height in cm' : 'Height in inches'}
          />
          <select
            value={formData.heightUnit}
            onChange={(e) => setFormData(prev => ({ ...prev, heightUnit: e.target.value }))}
            className="w-24 p-2 border rounded-lg"
          >
            <option value="cm">cm</option>
            <option value="in">in</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Weight</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={formData.weight}
            onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
            className="flex-1 p-2 border rounded-lg"
            placeholder={formData.weightUnit === 'kg' ? 'Weight in kg' : 'Weight in pounds'}
          />
          <select
            value={formData.weightUnit}
            onChange={(e) => setFormData(prev => ({ ...prev, weightUnit: e.target.value }))}
            className="w-24 p-2 border rounded-lg"
          >
            <option value="kg">kg</option>
            <option value="lb">lb</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Activity Level</label>
        <select
          value={formData.activityLevel}
          onChange={(e) => setFormData(prev => ({ ...prev, activityLevel: e.target.value }))}
          className="w-full p-2 border rounded-lg"
        >
          <option value="">Select activity level</option>
          <option value="not_active">Not Very Active (little or no exercise)</option>
          <option value="moderately_active">Moderately Active (exercise 3-5 days/week)</option>
          <option value="very_active">Very Active (exercise 6-7 days/week)</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Goal</label>
        <select
          value={formData.goal}
          onChange={(e) => setFormData(prev => ({ ...prev, goal: e.target.value }))}
          className="w-full p-2 border rounded-lg"
        >
          <option value="">Select your goal</option>
          <option value="lose_weight">Lose Weight</option>
          <option value="maintain_weight">Maintain Weight</option>
          <option value="gain_muscle">Gain Muscle</option>
          <option value="eat_healthier">Eat Healthier</option>
        </select>
      </div>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button 
          onClick={calculateMacros} 
          className="flex-1"
          disabled={!formData.age || !formData.height || !formData.weight || !formData.activityLevel || !formData.goal}
        >
          Calculate
        </Button>
      </div>
    </div>
  );
}