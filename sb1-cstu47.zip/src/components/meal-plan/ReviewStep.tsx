import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../Button';
import { ChevronLeft, AlertCircle } from 'lucide-react';
import { GeneratingPlanModal } from './GeneratingPlanModal';
import { generateMealPlan } from '../../lib/ai';
import { supabase } from '../../lib/supabase';
import type { Recipe } from '../../lib/ai';

interface ReviewStepProps {
  formData: {
    startDate: string;
    days: number;
    prompt: string;
    totalCalories: string;
    proteinGoal: string;
    carbsGoal: string;
    fatGoal: string;
    mealTypes: string[];
    excludedIngredients: string[];
    preferences: string[];
  };
  onBack: () => void;
}

export function ReviewStep({ formData, onBack }: ReviewStepProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Please sign in to create a meal plan.');
      }

      // Generate recipes using AI
      const recipes = await generateMealPlan({
        days: formData.days,
        prompt: formData.prompt,
        totalCalories: formData.totalCalories ? parseInt(formData.totalCalories) : undefined,
        proteinGoal: formData.proteinGoal ? parseFloat(formData.proteinGoal) : undefined,
        carbsGoal: formData.carbsGoal ? parseFloat(formData.carbsGoal) : undefined,
        fatGoal: formData.fatGoal ? parseFloat(formData.fatGoal) : undefined,
        mealTypes: formData.mealTypes,
        excludedIngredients: formData.excludedIngredients,
        preferences: formData.preferences
      });

      // Create meal plan
      const { data: mealPlan, error: mealPlanError } = await supabase
        .from('meal_plans')
        .insert({
          user_id: user.id,
          start_date: formData.startDate,
          days: formData.days,
          total_calories_per_day: formData.totalCalories ? parseInt(formData.totalCalories) : null,
          protein_goal_grams: formData.proteinGoal ? parseFloat(formData.proteinGoal) : null,
          carbs_goal_grams: formData.carbsGoal ? parseFloat(formData.carbsGoal) : null,
          fat_goal_grams: formData.fatGoal ? parseFloat(formData.fatGoal) : null,
          preferences: [formData.prompt, ...formData.preferences],
          excluded_ingredients: formData.excludedIngredients
        })
        .select()
        .single();

      if (mealPlanError) throw mealPlanError;
      if (!mealPlan) throw new Error('Failed to create meal plan');

      // Save recipes and create meal plan items
      const recipesData = await Promise.all(recipes.map(async (recipe: Recipe) => {
        const { data: savedRecipe, error: recipeError } = await supabase
          .from('recipes')
          .insert({
            name: recipe.name,
            description: recipe.description,
            instructions: recipe.instructions,
            ingredients: recipe.ingredients,
            prep_time_minutes: recipe.prep_time_minutes,
            cook_time_minutes: recipe.cook_time_minutes,
            difficulty: recipe.difficulty,
            calories: recipe.calories,
            protein_grams: recipe.protein_grams,
            carbs_grams: recipe.carbs_grams,
            fat_grams: recipe.fat_grams,
            servings: recipe.servings,
            created_by: user.id
          })
          .select()
          .single();

        if (recipeError) throw recipeError;
        return savedRecipe;
      }));

      // Create meal plan items
      const mealPlanItems = recipes.map((recipe, index) => ({
        meal_plan_id: mealPlan.id,
        recipe_id: recipesData[index].id,
        day_number: Math.floor(index / formData.mealTypes.length) + 1,
        meal_type: formData.mealTypes[index % formData.mealTypes.length],
        servings: recipe.servings,
        order_in_day: (index % formData.mealTypes.length) + 1
      }));

      const { error: itemsError } = await supabase
        .from('meal_plan_items')
        .insert(mealPlanItems);

      if (itemsError) throw itemsError;

      // Archive generated recipes
      await supabase
        .from('generated_recipes_archive')
        .insert({
          recipe: recipes,
          prompt: formData.prompt,
          preferences: formData.preferences,
          nutritional_targets: {
            calories: formData.totalCalories,
            protein: formData.proteinGoal,
            carbs: formData.carbsGoal,
            fat: formData.fatGoal
          }
        });

      // Navigate to the meal plan view
      navigate(`/meal-plan/${mealPlan.id}`);
    } catch (error) {
      console.error('Error creating meal plan:', error);
      setError(
        error instanceof Error 
          ? error.message 
          : 'Failed to create meal plan. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Plan Details</h3>
          <div className="bg-cream rounded-lg p-4">
            <p>Start Date: {new Date(formData.startDate).toLocaleDateString()}</p>
            <p>Duration: {formData.days} days</p>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Nutrition Goals</h3>
          <div className="bg-cream rounded-lg p-4">
            <p>Daily Calories: {formData.totalCalories || 'Not specified'}</p>
            <div className="grid grid-cols-3 gap-4 mt-2">
              <div>
                <p className="text-sm text-deep-olive">Protein</p>
                <p>{formData.proteinGoal || '0'}g</p>
              </div>
              <div>
                <p className="text-sm text-deep-olive">Carbs</p>
                <p>{formData.carbsGoal || '0'}g</p>
              </div>
              <div>
                <p className="text-sm text-deep-olive">Fat</p>
                <p>{formData.fatGoal || '0'}g</p>
              </div>
            </div>
          </div>
        </div>

        {formData.excludedIngredients.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Excluded Ingredients</h3>
            <div className="bg-cream rounded-lg p-4">
              <div className="flex flex-wrap gap-2">
                {formData.excludedIngredients.map((ingredient) => (
                  <span
                    key={ingredient}
                    className="bg-white px-3 py-1 rounded-full text-sm"
                  >
                    {ingredient}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {formData.preferences.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Additional Preferences</h3>
            <div className="bg-cream rounded-lg p-4">
              <div className="flex flex-wrap gap-2">
                {formData.preferences.map((pref) => (
                  <span
                    key={pref}
                    className="bg-white px-3 py-1 rounded-full text-sm"
                  >
                    {pref}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-spice-red/10 text-spice-red p-4 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}
      </div>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={onBack} disabled={loading}>
          <ChevronLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button 
          onClick={handleSubmit} 
          className="flex-1"
          disabled={loading}
        >
          {loading ? 'Creating Plan...' : 'Create Meal Plan'}
        </Button>
      </div>

      {loading && (
        <GeneratingPlanModal 
          totalMeals={formData.days * formData.mealTypes.length} 
        />
      )}
    </div>
  );
}