import { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, ArrowLeftRight } from 'lucide-react';
import { Button } from '../Button';
import { MealCard } from './MealCard';
import { RecipeDetails } from './RecipeDetails';
import type { MealPlan, Recipe } from '../../types/meal-plan';

interface WeeklyViewProps {
  mealPlan: MealPlan;
  selectedDay: string | null;
  onDaySelect: (date: string) => void;
  onSwapMeal: (mealId: string, targetMealId: string) => Promise<void>;
}

export function WeeklyView({ mealPlan, selectedDay, onDaySelect, onSwapMeal }: WeeklyViewProps) {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [currentWeekStart, setCurrentWeekStart] = useState<number>(0);
  const [swapMode, setSwapMode] = useState(false);
  const [selectedMealId, setSelectedMealId] = useState<string | null>(null);
  const daysToShow = 3;

  const visibleDays = mealPlan.days.slice(
    currentWeekStart,
    currentWeekStart + daysToShow
  );

  const canScrollLeft = currentWeekStart > 0;
  const canScrollRight = currentWeekStart + daysToShow < mealPlan.days.length;

  const handleMealClick = (meal: MealPlan['days'][0]['meals'][0]) => {
    if (swapMode) {
      if (selectedMealId) {
        if (selectedMealId !== meal.id) {
          onSwapMeal(selectedMealId, meal.id);
          setSwapMode(false);
          setSelectedMealId(null);
        }
      } else {
        setSelectedMealId(meal.id);
      }
    } else {
      setSelectedRecipe(meal.recipe);
    }
  };

  return (
    <div className="space-y-8">
      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="secondary"
          onClick={() => setCurrentWeekStart(prev => prev - daysToShow)}
          disabled={!canScrollLeft}
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <div className="flex gap-4">
          {visibleDays.map((day) => (
            <button
              key={day.date}
              onClick={() => onDaySelect(day.date)}
              className={`px-6 py-3 rounded-lg text-center transition-colors ${
                selectedDay === day.date
                  ? 'bg-terracotta text-white'
                  : 'bg-cream hover:bg-terracotta/10'
              }`}
            >
              <div className="font-semibold">
                {format(parseISO(day.date), 'EEE')}
              </div>
              <div className="text-sm">
                {format(parseISO(day.date), 'MMM d')}
              </div>
            </button>
          ))}
        </div>
        <Button
          variant="secondary"
          onClick={() => setCurrentWeekStart(prev => prev + daysToShow)}
          disabled={!canScrollRight}
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Swap Mode Toggle */}
      <div className="flex justify-end">
        <Button
          variant={swapMode ? 'primary' : 'secondary'}
          onClick={() => {
            setSwapMode(!swapMode);
            setSelectedMealId(null);
          }}
        >
          <ArrowLeftRight className="w-4 h-4 mr-2" />
          {swapMode ? 'Cancel Swap' : 'Swap Meals'}
        </Button>
      </div>

      {/* Meals Grid */}
      <div className="grid grid-cols-3 gap-8">
        {visibleDays.map((day) => (
          <div key={day.date} className="space-y-6">
            {day.meals.map((meal) => (
              <div
                key={meal.id}
                className={`transition-all ${
                  swapMode && selectedMealId === meal.id
                    ? 'ring-2 ring-terracotta rounded-lg'
                    : ''
                }`}
              >
                <MealCard
                  meal={meal}
                  isSelected={selectedDay === day.date}
                  onClick={() => handleMealClick(meal)}
                  swapMode={swapMode}
                  isSwapSource={selectedMealId === meal.id}
                  isSwapTarget={swapMode && selectedMealId !== null && selectedMealId !== meal.id}
                />
              </div>
            ))}
            <div className="bg-cream rounded-lg p-4">
              <div className="font-semibold mb-2">Daily Totals</div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Calories: {day.total_calories}</div>
                <div>Protein: {day.total_protein}g</div>
                <div>Carbs: {day.total_carbs}g</div>
                <div>Fat: {day.total_fat}g</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recipe Details Modal */}
      {selectedRecipe && !swapMode && (
        <RecipeDetails
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
        />
      )}
    </div>
  );
}