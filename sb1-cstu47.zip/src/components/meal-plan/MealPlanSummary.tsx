import { Info, Calendar, Target } from 'lucide-react';
import type { MealPlan } from '../../types/meal-plan';
import { format, parseISO } from 'date-fns';

interface MealPlanSummaryProps {
  mealPlan: MealPlan;
}

export function MealPlanSummary({ mealPlan }: MealPlanSummaryProps) {
  // Find recipes that need advance preparation
  const advancePreparationNotes = mealPlan.days.flatMap(day => 
    day.meals
      .filter(meal => {
        const lowerInstructions = meal.recipe.instructions.join(' ').toLowerCase();
        return (
          lowerInstructions.includes('overnight') ||
          lowerInstructions.includes('advance') ||
          lowerInstructions.includes('ahead') ||
          lowerInstructions.includes('marinate') ||
          lowerInstructions.includes('soak')
        );
      })
      .map(meal => ({
        date: day.date,
        name: meal.recipe.name,
        type: meal.type,
        instructions: meal.recipe.instructions
          .filter(instruction => 
            instruction.toLowerCase().includes('overnight') ||
            instruction.toLowerCase().includes('advance') ||
            instruction.toLowerCase().includes('ahead') ||
            instruction.toLowerCase().includes('marinate') ||
            instruction.toLowerCase().includes('soak')
          )
      }))
  );

  // Calculate daily averages
  const averages = mealPlan.days.reduce(
    (acc, day) => ({
      calories: acc.calories + day.total_calories,
      protein: acc.protein + day.total_protein,
      carbs: acc.carbs + day.total_carbs,
      fat: acc.fat + day.total_fat
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const totalDays = mealPlan.days.length;
  averages.calories = Math.round(averages.calories / totalDays);
  averages.protein = Math.round(averages.protein / totalDays);
  averages.carbs = Math.round(averages.carbs / totalDays);
  averages.fat = Math.round(averages.fat / totalDays);

  return (
    <div className="bg-cream rounded-2xl p-6 mb-8">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Plan Overview */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-terracotta" />
            Plan Overview
          </h2>
          <div className="space-y-2">
            <p>
              <span className="font-semibold">Duration:</span> {mealPlan.days.length} days
            </p>
            <p>
              <span className="font-semibold">Start Date:</span>{' '}
              {format(parseISO(mealPlan.start_date), 'MMMM d, yyyy')}
            </p>
            <p>
              <span className="font-semibold">End Date:</span>{' '}
              {format(parseISO(mealPlan.days[mealPlan.days.length - 1].date), 'MMMM d, yyyy')}
            </p>
          </div>

          <h3 className="text-lg font-semibold mt-6 mb-3 flex items-center gap-2">
            <Target className="w-5 h-5 text-terracotta" />
            Daily Averages
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-deep-olive text-sm">Calories</div>
              <div className="font-semibold">{averages.calories}</div>
            </div>
            <div>
              <div className="text-deep-olive text-sm">Protein</div>
              <div className="font-semibold">{averages.protein}g</div>
            </div>
            <div>
              <div className="text-deep-olive text-sm">Carbs</div>
              <div className="font-semibold">{averages.carbs}g</div>
            </div>
            <div>
              <div className="text-deep-olive text-sm">Fat</div>
              <div className="font-semibold">{averages.fat}g</div>
            </div>
          </div>
        </div>

        {/* Preparation Notes */}
        {advancePreparationNotes.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Info className="w-5 h-5 text-terracotta" />
              Advance Preparation Required
            </h2>
            <div className="space-y-4">
              {advancePreparationNotes.map((note, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg p-4 shadow-sm"
                >
                  <div className="font-semibold mb-1">
                    {note.name} ({note.type})
                  </div>
                  <div className="text-sm text-deep-olive mb-2">
                    {format(parseISO(note.date), 'MMMM d, yyyy')}
                  </div>
                  <ul className="text-sm space-y-1">
                    {note.instructions.map((instruction, i) => (
                      <li key={i} className="text-deep-olive">
                        • {instruction}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}