import { useState } from 'react';
import { X, Clock, ChefHat, Users } from 'lucide-react';
import { Button } from '../Button';
import type { Recipe } from '../../types/meal-plan';

interface RecipeDetailsProps {
  recipe: Recipe;
  onClose: () => void;
}

export function RecipeDetails({ recipe, onClose }: RecipeDetailsProps) {
  return (
    <div className="fixed inset-0 bg-charcoal/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-display font-bold">{recipe.name}</h2>
            <button onClick={onClose}>
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {/* Description */}
            <p className="text-deep-olive">{recipe.description}</p>

            {/* Meta Info */}
            <div className="flex items-center gap-6 text-deep-olive">
              <div className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                <div>
                  <div className="text-sm">Total Time</div>
                  <div>{recipe.prep_time_minutes + recipe.cook_time_minutes} min</div>
                </div>
              </div>
              <div className="flex items-center">
                <ChefHat className="w-5 h-5 mr-2" />
                <div>
                  <div className="text-sm">Difficulty</div>
                  <div className="capitalize">{recipe.difficulty}</div>
                </div>
              </div>
              <div className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                <div>
                  <div className="text-sm">Servings</div>
                  <div>{recipe.servings}</div>
                </div>
              </div>
            </div>

            {/* Nutritional Info */}
            <div className="bg-cream rounded-lg p-4">
              <h3 className="font-semibold mb-2">Nutrition Per Serving</h3>
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <div className="text-sm text-deep-olive">Calories</div>
                  <div className="font-semibold">{recipe.calories}</div>
                </div>
                <div>
                  <div className="text-sm text-deep-olive">Protein</div>
                  <div className="font-semibold">{recipe.protein_grams}g</div>
                </div>
                <div>
                  <div className="text-sm text-deep-olive">Carbs</div>
                  <div className="font-semibold">{recipe.carbs_grams}g</div>
                </div>
                <div>
                  <div className="text-sm text-deep-olive">Fat</div>
                  <div className="font-semibold">{recipe.fat_grams}g</div>
                </div>
              </div>
            </div>

            {/* Ingredients */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Ingredients</h3>
              <ul className="grid md:grid-cols-2 gap-2">
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-baseline gap-2">
                    <span className="font-semibold">
                      {ingredient.amount} {ingredient.unit}
                    </span>
                    <span>{ingredient.item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructions */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Instructions</h3>
              <ol className="space-y-4">
                {recipe.instructions.map((step, index) => (
                  <li key={index} className="flex gap-4">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-terracotta text-white flex items-center justify-center">
                      {index + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        <div className="p-6 border-t">
          <Button onClick={onClose} className="w-full">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}