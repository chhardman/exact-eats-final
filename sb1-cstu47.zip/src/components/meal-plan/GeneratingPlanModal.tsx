import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface GeneratingPlanModalProps {
  totalMeals: number;
}

export function GeneratingPlanModal({ totalMeals }: GeneratingPlanModalProps) {
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('Analyzing your preferences...');

  useEffect(() => {
    const messages = [
      'Analyzing your preferences...',
      'Calculating nutritional requirements...',
      'Designing your meal plan...',
      'Generating recipes...',
      'Balancing macronutrients...',
      'Finalizing your plan...'
    ];

    let currentMessage = 0;
    const messageInterval = setInterval(() => {
      currentMessage = (currentMessage + 1) % messages.length;
      setMessage(messages[currentMessage]);
    }, 3000);

    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) return prev;
        return prev + Math.random() * 15;
      });
    }, 2000);

    return () => {
      clearInterval(messageInterval);
      clearInterval(progressInterval);
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-charcoal/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center">
        <Loader2 className="w-12 h-12 text-terracotta animate-spin mx-auto mb-4" />
        <h2 className="text-2xl font-display font-bold mb-4">
          Creating Your Meal Plan
        </h2>
        <p className="text-deep-olive mb-6">{message}</p>
        <div className="w-full bg-cream rounded-full h-2 mb-2">
          <div
            className="bg-terracotta h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-sm text-deep-olive">
          Generating {totalMeals} meals for your plan...
        </p>
      </div>
    </div>
  );
}