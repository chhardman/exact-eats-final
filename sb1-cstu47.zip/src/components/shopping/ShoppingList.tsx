import { useState } from 'react';
import { Trash2, BarChart3, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '../Button';
import type { ShoppingListItem } from '../../types/shopping';
import { supabase } from '../../lib/supabase';
import { optimizeShoppingList } from '../../lib/ai/client';

interface ShoppingListProps {
  id: string;
  name: string;
  items: ShoppingListItem[];
  onOptimize: () => Promise<void>;
  onDelete: () => Promise<void>;
  onToggleItem: (itemId: string, checked: boolean) => Promise<void>;
}

export function ShoppingList({
  id,
  name,
  items,
  onOptimize,
  onDelete,
  onToggleItem
}: ShoppingListProps) {
  const [optimizing, setOptimizing] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [optimizationStep, setOptimizationStep] = useState<string>('');

  const handleOptimize = async () => {
    try {
      setOptimizing(true);
      setError(null);
      setOptimizationStep('Analyzing items...');

      const optimizedItems = await optimizeShoppingList(items);

      setOptimizationStep('Updating list...');

      const { error: deleteError } = await supabase
        .from('shopping_list_items')
        .delete()
        .eq('shopping_list_id', id);

      if (deleteError) throw deleteError;

      const { error: insertError } = await supabase
        .from('shopping_list_items')
        .insert(optimizedItems);

      if (insertError) throw insertError;

      await onOptimize();
    } catch (err) {
      console.error('Error optimizing list:', err);
      setError(err instanceof Error ? err.message : 'Failed to optimize list');
    } finally {
      setOptimizing(false);
      setOptimizationStep('');
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this list?')) return;
    
    try {
      setDeleting(true);
      setError(null);
      await onDelete();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete list');
    } finally {
      setDeleting(false);
    }
  };

  const handleToggleItem = async (itemId: string, checked: boolean) => {
    try {
      await onToggleItem(itemId, checked);

      if (checked) {
        const item = items.find(i => i.id === itemId);
        if (!item) return;

        const addToPantry = window.confirm(
          'Would you like to add this item to your pantry?'
        );

        if (addToPantry) {
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) throw new Error('Not authenticated');

          const { error } = await supabase
            .from('pantry_items')
            .insert({
              user_id: user.id,
              name: item.item,
              amount: item.amount,
              unit: item.unit,
              category: item.category
            });

          if (error) throw error;
        }
      }
    } catch (error) {
      console.error('Error updating item:', error);
    }
  };

  // Group items by category
  const groupedItems = items.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, ShoppingListItem[]>);

  return (
    <div className="border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">{name}</h2>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleOptimize}
            disabled={optimizing || !items.length}
          >
            {optimizing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <BarChart3 className="w-4 h-4 mr-2" />
                Optimize
              </>
            )}
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={handleDelete}
            disabled={deleting || optimizing}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            {deleting ? 'Deleting...' : 'Delete'}
          </Button>
        </div>
      </div>

      {optimizing && (
        <div className="mb-4 p-4 bg-cream rounded-lg">
          <div className="flex items-center gap-3">
            <Loader2 className="w-5 h-5 text-terracotta animate-spin" />
            <div>
              <p className="font-medium">{optimizationStep}</p>
              <p className="text-sm text-deep-olive">
                This may take a minute. We're using AI to optimize your list.
              </p>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="mb-4 p-3 bg-spice-red/10 text-spice-red rounded-lg flex items-center gap-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {items.length === 0 ? (
        <p className="text-deep-olive text-center py-8">
          This shopping list is empty
        </p>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedItems).map(([category, items]) => (
            <div key={category}>
              <h3 className="font-semibold capitalize mb-2">{category}</h3>
              <div className="space-y-2">
                {items.map(item => (
                  <div 
                    key={item.id}
                    className={`flex items-center gap-3 p-2 rounded-lg hover:bg-cream transition-colors ${
                      item.checked ? 'text-deep-olive' : ''
                    }`}
                  >
                    <label className="flex items-center gap-3 flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={item.checked}
                        onChange={(e) => handleToggleItem(item.id, e.target.checked)}
                        className="w-5 h-5 rounded border-deep-olive text-terracotta focus:ring-terracotta"
                        disabled={optimizing}
                      />
                      <span className={item.checked ? 'line-through' : ''}>
                        {item.amount} {item.unit} {item.item}
                      </span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}