import { format } from 'date-fns';
import { Trash2 } from 'lucide-react';
import { Button } from '../Button';
import { supabase } from '../../lib/supabase';
import type { PantryItem } from '../../types/pantry';

interface PantryListProps {
  items: PantryItem[];
  onUpdate: () => Promise<void>;
}

export function PantryList({ items, onUpdate }: PantryListProps) {
  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('pantry_items')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await onUpdate();
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  // Group items by category
  const groupedItems = items.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, PantryItem[]>);

  return (
    <div className="space-y-8">
      {Object.entries(groupedItems).map(([category, items]) => (
        <div key={category}>
          <h3 className="font-semibold capitalize mb-4">{category}</h3>
          <div className="space-y-2">
            {items.map(item => (
              <div 
                key={item.id}
                className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">{item.name}</span>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => handleDelete(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="text-deep-olive">
                    {item.amount} {item.unit}
                  </div>
                  {item.expiration_date && (
                    <div className={`text-sm ${
                      new Date(item.expiration_date) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
                        ? 'text-spice-red'
                        : 'text-deep-olive'
                    }`}>
                      Expires: {format(new Date(item.expiration_date), 'MMM d, yyyy')}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {Object.keys(groupedItems).length === 0 && (
        <div className="text-center py-8 text-deep-olive">
          No items in your pantry yet
        </div>
      )}
    </div>
  );
}