import { Crown } from 'lucide-react';
import { useSubscription } from '../../contexts/SubscriptionContext';

export function SubscriptionBadge() {
  const { profile } = useSubscription();

  if (!profile || profile.subscription_tier === 'free') {
    return null;
  }

  return (
    <div className="flex items-center gap-1 text-warm-gold">
      <Crown className="w-4 h-4" />
      <span className="text-sm font-medium">Premium</span>
    </div>
  );
}