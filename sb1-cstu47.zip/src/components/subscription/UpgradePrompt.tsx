import { useState } from 'react';
import { Crown, Loader2 } from 'lucide-react';
import { Button } from '../Button';
import { createCheckoutSession } from '../../lib/stripe';
import { useSubscription } from '../../contexts/SubscriptionContext';

interface UpgradePromptProps {
  feature: 'meal-plan' | 'shopping-list' | 'pantry' | 'general';
  onClose?: () => void;
}

export function UpgradePrompt({ feature, onClose }: UpgradePromptProps) {
  const { profile } = useSubscription();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpgrade = async (billingPeriod: 'monthly' | 'annual') => {
    try {
      setLoading(true);
      setError(null);
      
      if (!profile) throw new Error('No user profile found');
      await createCheckoutSession(profile.id, billingPeriod);
    } catch (error) {
      console.error('Error starting checkout:', error);
      setError(error instanceof Error ? error.message : 'Failed to start checkout');
    } finally {
      setLoading(false);
    }
  };

  const getFeatureMessage = () => {
    switch (feature) {
      case 'meal-plan':
        return 'Generate up to 5 weekly meal plans per month';
      case 'shopping-list':
        return 'Optimize your shopping lists and sync with your pantry';
      case 'pantry':
        return 'Track your pantry inventory and get expiration alerts';
      default:
        return 'Access all premium features';
    }
  };

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <Crown className="w-8 h-8 text-warm-gold" />
        <h2 className="text-2xl font-display font-bold">Upgrade to Premium</h2>
      </div>

      {error && (
        <div className="bg-spice-red/10 text-spice-red p-4 rounded-lg mb-6">
          {error}
        </div>
      )}

      <p className="text-deep-olive mb-6">
        {getFeatureMessage()}
      </p>

      <div className="grid md:grid-cols-2 gap-4 mb-6">
        <div className="border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold mb-2">$25</div>
          <div className="text-deep-olive mb-4">per month</div>
          <Button 
            onClick={() => handleUpgrade('monthly')} 
            className="w-full"
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              'Subscribe Monthly'
            )}
          </Button>
        </div>

        <div className="border-2 border-terracotta rounded-lg p-4 text-center relative">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-terracotta text-white px-3 py-1 rounded-full text-sm">
            Save 17%
          </div>
          <div className="text-2xl font-bold mb-2">$250</div>
          <div className="text-deep-olive mb-4">per year</div>
          <Button 
            onClick={() => handleUpgrade('annual')} 
            className="w-full"
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              'Subscribe Yearly'
            )}
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-semibold mb-2">Premium Features:</h3>
        <ul className="space-y-2">
          <li className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-warm-gold" />
            Generate up to 5 weekly meal plans per month
          </li>
          <li className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-warm-gold" />
            Unlimited shopping list optimization
          </li>
          <li className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-warm-gold" />
            Pantry management system
          </li>
          <li className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-warm-gold" />
            Smart recipe suggestions
          </li>
        </ul>
      </div>

      {onClose && (
        <Button 
          variant="secondary" 
          onClick={onClose} 
          className="w-full mt-6"
          disabled={loading}
        >
          Maybe Later
        </Button>
      )}
    </div>
  );
}