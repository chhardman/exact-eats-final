interface TestimonialCardProps {
  quote: string;
  author: string;
  role: string;
  image: string;
}

export function TestimonialCard({ quote, author, role, image }: TestimonialCardProps) {
  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <img
        src={image}
        alt={author}
        className="w-16 h-16 rounded-full object-cover mx-auto mb-4"
      />
      <p className="text-lg italic text-charcoal mb-4">{quote}</p>
      <div className="text-center">
        <h4 className="font-semibold text-deep-olive">{author}</h4>
        <p className="text-sm text-gray-600">{role}</p>
      </div>
    </div>
  );
}