import { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface SubscriptionContextType {
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  canGenerateMealPlan: boolean;
  canOptimizeShoppingList: boolean;
  canAccessPremiumFeatures: boolean;
  remainingMealPlans: number;
  refreshProfile: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  const loadProfile = async () => {
    try {
      setError(null);
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      
      if (authError) {
        console.error('Auth error:', authError);
        setProfile(null);
        return;
      }

      if (!user) {
        setProfile(null);
        return;
      }

      const { data, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileError) {
        if (profileError.code === 'PGRST116') {
          // Profile doesn't exist, create it
          const { data: newProfile, error: createError } = await supabase
            .from('profiles')
            .insert({ id: user.id })
            .select()
            .single();

          if (createError) throw createError;
          setProfile(newProfile);
        } else {
          throw profileError;
        }
      } else {
        setProfile(data);
      }
    } catch (err) {
      console.error('Error loading profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to load profile');
      setProfile(null);
    } finally {
      setLoading(false);
      setInitialized(true);
    }
  };

  useEffect(() => {
    loadProfile();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN' || event === 'SIGNED_OUT') {
        loadProfile();
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const canGenerateMealPlan = profile ? (
    profile.subscription_tier === 'premium'
      ? (profile.meal_plans_generated_this_month || 0) < 5
      : (profile.meal_plans_generated_this_month || 0) === 0
  ) : false;

  const canOptimizeShoppingList = profile ? (
    profile.subscription_tier === 'premium' || !profile.shopping_list_optimizations_used
  ) : false;

  const canAccessPremiumFeatures = profile ? (
    profile.subscription_tier === 'premium' && profile.subscription_status === 'active'
  ) : false;

  const remainingMealPlans = profile ? (
    profile.subscription_tier === 'premium'
      ? 5 - (profile.meal_plans_generated_this_month || 0)
      : 1 - (profile.meal_plans_generated_this_month || 0)
  ) : 0;

  // Don't render children until we've completed initial load
  if (!initialized) {
    return null;
  }

  const value = {
    profile,
    loading,
    error,
    canGenerateMealPlan,
    canOptimizeShoppingList,
    canAccessPremiumFeatures,
    remainingMealPlans,
    refreshProfile: loadProfile
  };

  return (
    <SubscriptionContext.Provider value={value}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}