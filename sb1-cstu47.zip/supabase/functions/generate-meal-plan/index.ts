import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { Anthropic } from 'https://esm.sh/@anthropic-ai/sdk@0.18.0';
import { corsHeaders } from '../_shared/cors.ts';

const anthropic = new Anthropic({
  apiKey: Deno.env.get('ANTHROPIC_API_KEY')!,
});

function validateRecipe(recipe: any) {
  const requiredFields = [
    'name',
    'description',
    'instructions',
    'ingredients',
    'prep_time_minutes',
    'cook_time_minutes',
    'difficulty',
    'calories',
    'protein_grams',
    'carbs_grams',
    'fat_grams',
    'servings'
  ];

  return requiredFields.every(field => {
    if (field === 'instructions' || field === 'ingredients') {
      return Array.isArray(recipe[field]) && recipe[field].length > 0;
    }
    return recipe[field] !== undefined && recipe[field] !== null;
  });
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { params } = await req.json();

    if (!params?.days || !params?.mealTypes?.length) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required parameters: days and mealTypes are required' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt || 'No specific requirements'}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients?.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences?.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

For each meal, provide:
1. Recipe name
2. Brief description (2-3 sentences maximum)
3. List of ingredients with precise measurements
4. Step-by-step instructions (clear and concise)
5. Preparation time (realistic estimate)
6. Cooking time (realistic estimate)
7. Difficulty level (easy/medium/hard)
8. Nutritional information per serving (calories, protein, carbs, fat)
9. Number of servings (default to 4 if not specified)

Format the response as a JSON array of recipes. Each recipe must follow this exact structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}`;

    const userPrompt = "Generate a complete meal plan following the requirements above. The response must be a valid JSON array of recipes.";

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    });

    const content = response.content[0].text;
    
    // Find the JSON array in the response
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      return new Response(
        JSON.stringify({ 
          error: 'Failed to generate a valid meal plan. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    let recipes;
    try {
      recipes = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('JSON parse error:', error);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to parse the generated meal plan. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Validate the recipes
    if (!Array.isArray(recipes)) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid response format. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    if (recipes.length !== params.days * params.mealTypes.length) {
      return new Response(
        JSON.stringify({ 
          error: 'Incomplete meal plan generated. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Validate each recipe
    const invalidRecipes = recipes.filter(recipe => !validateRecipe(recipe));
    if (invalidRecipes.length > 0) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid recipe format detected. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    return new Response(
      JSON.stringify(recipes),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('API error:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'An unexpected error occurred. Please try again.' 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});