import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { Anthropic } from 'https://esm.sh/@anthropic-ai/sdk@0.18.0';
import { corsHeaders } from '../_shared/cors.ts';

const anthropic = new Anthropic({
  apiKey: Deno.env.get('ANTHROPIC_API_KEY')!,
});

function validateRecipe(recipe: any) {
  const requiredFields = [
    'name',
    'description',
    'instructions',
    'ingredients',
    'prep_time_minutes',
    'cook_time_minutes',
    'difficulty',
    'calories',
    'protein_grams',
    'carbs_grams',
    'fat_grams',
    'servings'
  ];

  return requiredFields.every(field => {
    if (field === 'instructions' || field === 'ingredients') {
      return Array.isArray(recipe[field]) && recipe[field].length > 0;
    }
    return recipe[field] !== undefined && recipe[field] !== null;
  });
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { originalRecipe, preferences } = await req.json();

    if (!originalRecipe || !validateRecipe(originalRecipe)) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid or missing recipe data' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(originalRecipe, null, 2)}

Additional Preferences: ${preferences?.join(', ') || 'None'}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people

Format the response as a single JSON recipe object following this structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}`;

    const userPrompt = "Generate a new recipe that matches the nutritional profile of the original recipe but offers variety in ingredients and preparation method.";

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    });

    const content = response.content[0].text;
    
    // Find the JSON object in the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return new Response(
        JSON.stringify({ 
          error: 'Failed to generate a valid recipe. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    let recipe;
    try {
      recipe = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('JSON parse error:', error);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to parse the generated recipe. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Validate the recipe
    if (!validateRecipe(recipe)) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid recipe format generated. Please try again.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    return new Response(
      JSON.stringify(recipe),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('API error:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'An unexpected error occurred. Please try again.' 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});