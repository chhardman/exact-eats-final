-- Create pantry_items table
create table pantry_items (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  user_id uuid references auth.users on delete cascade not null,
  name text not null,
  amount numeric not null,
  unit text not null,
  expiration_date date,
  low_threshold numeric,
  track_consumption boolean default false,
  last_consumed timestamp with time zone,
  avg_consumption_rate numeric,
  confidence_score numeric -- For AI-detected items
);

-- Create pantry_item_history table for consumption tracking
create table pantry_item_history (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  pantry_item_id uuid references pantry_items on delete cascade not null,
  event_type text not null check (event_type in ('added', 'consumed', 'expired')),
  amount numeric not null,
  unit text not null
);

-- Add RLS policies
alter table pantry_items enable row level security;
alter table pantry_item_history enable row level security;

-- Pantry items policies
create policy "Users can view their pantry items"
  on pantry_items for select
  to authenticated
  using (auth.uid() = user_id);

create policy "Users can manage their pantry items"
  on pantry_items for all
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Pantry history policies
create policy "Users can view their pantry history"
  on pantry_item_history for select
  to authenticated
  using (
    exists (
      select 1 from pantry_items
      where pantry_items.id = pantry_item_history.pantry_item_id
      and pantry_items.user_id = auth.uid()
    )
  );

create policy "Users can add pantry history"
  on pantry_item_history for insert
  to authenticated
  with check (
    exists (
      select 1 from pantry_items
      where pantry_items.id = pantry_item_history.pantry_item_id
      and pantry_items.user_id = auth.uid()
    )
  );

-- Function to update consumption rate
create or replace function update_consumption_rate()
returns trigger as $$
begin
  if new.event_type = 'consumed' and exists (
    select 1 from pantry_items
    where id = new.pantry_item_id
    and track_consumption = true
  ) then
    -- Calculate average consumption over the last 30 days
    update pantry_items
    set avg_consumption_rate = (
      select coalesce(sum(amount), 0) / 30
      from pantry_item_history
      where pantry_item_id = new.pantry_item_id
      and event_type = 'consumed'
      and created_at > now() - interval '30 days'
    ),
    last_consumed = now()
    where id = new.pantry_item_id;
  end if;
  return new;
end;
$$ language plpgsql security definer;

-- Trigger to update consumption rate
create trigger on_pantry_history_insert
  after insert on pantry_item_history
  for each row
  execute function update_consumption_rate();