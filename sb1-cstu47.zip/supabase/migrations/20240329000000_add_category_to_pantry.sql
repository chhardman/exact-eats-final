-- Add category column to pantry_items table
ALTER TABLE pantry_items 
ADD COLUMN IF NOT EXISTS category text CHECK (
  category IN ('produce', 'meat', 'dairy', 'pantry', 'spices', 'frozen', 'other')
) NOT NULL DEFAULT 'other';