-- Drop existing tables if they exist
DROP TABLE IF EXISTS shopping_list_items;
DROP TABLE IF EXISTS shopping_lists;

-- Create shopping lists table
CREATE TABLE shopping_lists (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  user_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  meal_plan_id uuid REFERENCES meal_plans ON DELETE SET NULL,
  name text NOT NULL,
  notes text,
  archived boolean DEFAULT false
);

-- Create shopping list items table
CREATE TABLE shopping_list_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  shopping_list_id uuid REFERENCES shopping_lists ON DELETE CASCADE NOT NULL,
  item text NOT NULL,
  amount numeric NOT NULL,
  unit text NOT NULL,
  category text NOT NULL,
  checked boolean DEFAULT false,
  recipe_id uuid REFERENCES recipes ON DELETE SET NULL,
  meal_plan_item_id uuid REFERENCES meal_plan_items ON DELETE SET NULL,
  recipe_amount text,
  pantry_status text CHECK (pantry_status IN ('available', 'partial', 'low') OR pantry_status IS NULL)
);

-- Enable RLS
ALTER TABLE shopping_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE shopping_list_items ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view their shopping lists" ON shopping_lists;
DROP POLICY IF EXISTS "Users can insert their shopping lists" ON shopping_lists;
DROP POLICY IF EXISTS "Users can update their shopping lists" ON shopping_lists;
DROP POLICY IF EXISTS "Users can delete their shopping lists" ON shopping_lists;

DROP POLICY IF EXISTS "Users can view their shopping list items" ON shopping_list_items;
DROP POLICY IF EXISTS "Users can insert their shopping list items" ON shopping_list_items;
DROP POLICY IF EXISTS "Users can update their shopping list items" ON shopping_list_items;
DROP POLICY IF EXISTS "Users can delete their shopping list items" ON shopping_list_items;

-- Create policies for shopping lists
CREATE POLICY "Users can view their shopping lists"
  ON shopping_lists FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their shopping lists"
  ON shopping_lists FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their shopping lists"
  ON shopping_lists FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their shopping lists"
  ON shopping_lists FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for shopping list items
CREATE POLICY "Users can view their shopping list items"
  ON shopping_list_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM shopping_lists
      WHERE shopping_lists.id = shopping_list_items.shopping_list_id
      AND shopping_lists.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert their shopping list items"
  ON shopping_list_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM shopping_lists
      WHERE shopping_lists.id = shopping_list_items.shopping_list_id
      AND shopping_lists.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their shopping list items"
  ON shopping_list_items FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM shopping_lists
      WHERE shopping_lists.id = shopping_list_items.shopping_list_id
      AND shopping_lists.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete their shopping list items"
  ON shopping_list_items FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM shopping_lists
      WHERE shopping_lists.id = shopping_list_items.shopping_list_id
      AND shopping_lists.user_id = auth.uid()
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_shopping_lists_updated_at
  BEFORE UPDATE ON shopping_lists
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_shopping_list_items_updated_at
  BEFORE UPDATE ON shopping_list_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();