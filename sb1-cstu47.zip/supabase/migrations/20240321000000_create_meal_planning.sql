-- Create recipes table if it doesn't exist
CREATE TABLE IF NOT EXISTS recipes (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  name text not null,
  description text,
  instructions text[] not null,
  ingredients jsonb not null,
  prep_time_minutes integer,
  cook_time_minutes integer,
  difficulty text check (difficulty in ('easy', 'medium', 'hard')),
  calories integer,
  protein_grams numeric,
  carbs_grams numeric,
  fat_grams numeric,
  servings integer,
  tags text[],
  is_batch_cooking boolean default false,
  image_url text
);

-- Create meal_plans table
CREATE TABLE IF NOT EXISTS meal_plans (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  user_id uuid references auth.users on delete cascade not null,
  start_date date not null,
  days integer not null,
  total_calories_per_day integer,
  protein_goal_grams numeric,
  carbs_goal_grams numeric,
  fat_goal_grams numeric,
  preferences text[],
  excluded_ingredients text[]
);

-- Create meal_plan_items table to store individual meals in a plan
CREATE TABLE IF NOT EXISTS meal_plan_items (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  meal_plan_id uuid references meal_plans on delete cascade not null,
  recipe_id uuid references recipes on delete cascade not null,
  day_number integer not null,
  meal_type text not null,
  servings integer not null,
  order_in_day integer not null
);

-- Create favorite_recipes table
CREATE TABLE IF NOT EXISTS favorite_recipes (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  user_id uuid references auth.users on delete cascade not null,
  recipe_id uuid references recipes on delete cascade not null,
  unique(user_id, recipe_id)
);

-- Add RLS policies
ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;
ALTER TABLE meal_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE meal_plan_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorite_recipes ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view their own meal plans" ON meal_plans;
DROP POLICY IF EXISTS "Users can insert their own meal plans" ON meal_plans;
DROP POLICY IF EXISTS "Users can update their own meal plans" ON meal_plans;
DROP POLICY IF EXISTS "Users can delete their own meal plans" ON meal_plans;

DROP POLICY IF EXISTS "Users can view their meal plan items" ON meal_plan_items;
DROP POLICY IF EXISTS "Users can insert meal plan items" ON meal_plan_items;
DROP POLICY IF EXISTS "Users can update their meal plan items" ON meal_plan_items;
DROP POLICY IF EXISTS "Users can delete their meal plan items" ON meal_plan_items;

DROP POLICY IF EXISTS "Users can view their favorite recipes" ON favorite_recipes;
DROP POLICY IF EXISTS "Users can manage their favorite recipes" ON favorite_recipes;

-- Create meal plans policies
CREATE POLICY "Users can view their own meal plans"
  ON meal_plans FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own meal plans"
  ON meal_plans FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own meal plans"
  ON meal_plans FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own meal plans"
  ON meal_plans FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Meal plan items policies
CREATE POLICY "Users can view their meal plan items"
  ON meal_plan_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM meal_plans
      WHERE meal_plans.id = meal_plan_items.meal_plan_id
      AND meal_plans.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert meal plan items"
  ON meal_plan_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM meal_plans
      WHERE meal_plans.id = meal_plan_items.meal_plan_id
      AND meal_plans.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their meal plan items"
  ON meal_plan_items FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM meal_plans
      WHERE meal_plans.id = meal_plan_items.meal_plan_id
      AND meal_plans.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete their meal plan items"
  ON meal_plan_items FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM meal_plans
      WHERE meal_plans.id = meal_plan_items.meal_plan_id
      AND meal_plans.user_id = auth.uid()
    )
  );

-- Favorite recipes policies
CREATE POLICY "Users can view their favorite recipes"
  ON favorite_recipes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their favorite recipes"
  ON favorite_recipes FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);