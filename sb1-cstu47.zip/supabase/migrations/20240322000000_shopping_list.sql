-- Create unit_conversions table
create table unit_conversions (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  ingredient_type text not null,
  from_unit text not null,
  to_unit text not null,
  conversion_factor numeric not null,
  unique(ingredient_type, from_unit, to_unit)
);

-- Create user_preferred_units table
create table user_preferred_units (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  user_id uuid references auth.users on delete cascade not null,
  ingredient_type text not null,
  preferred_unit text not null,
  unique(user_id, ingredient_type)
);

-- Add RLS policies
alter table unit_conversions enable row level security;
alter table user_preferred_units enable row level security;

-- Unit conversions are readable by all authenticated users
create policy "Unit conversions are viewable by all users"
  on unit_conversions for select
  to authenticated
  using (true);

-- Users can manage their preferred units
create policy "Users can view their preferred units"
  on user_preferred_units for select
  to authenticated
  using (auth.uid() = user_id);

create policy "Users can manage their preferred units"
  on user_preferred_units for all
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Insert some common unit conversions
insert into unit_conversions (ingredient_type, from_unit, to_unit, conversion_factor) values
  -- Volume conversions
  ('liquid', 'tbsp', 'cup', 0.0625),
  ('liquid', 'tsp', 'tbsp', 0.333333),
  ('liquid', 'cup', 'gallon', 0.0625),
  ('liquid', 'cup', 'quart', 0.25),
  ('liquid', 'cup', 'pint', 0.5),
  ('liquid', 'fl oz', 'cup', 0.125),
  
  -- Weight conversions
  ('dry', 'oz', 'lb', 0.0625),
  ('dry', 'g', 'kg', 0.001),
  ('dry', 'oz', 'g', 28.3495),
  
  -- Common ingredient specific conversions
  ('flour', 'cup', 'lb', 0.2375),
  ('sugar', 'cup', 'lb', 0.4375),
  ('rice', 'cup', 'lb', 0.4375),
  ('butter', 'tbsp', 'stick', 0.125),
  ('butter', 'cup', 'stick', 2);