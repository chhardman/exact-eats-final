-- Add advance_prep column to recipes table
ALTER TABLE recipes ADD COLUMN IF NOT EXISTS advance_prep jsonb;