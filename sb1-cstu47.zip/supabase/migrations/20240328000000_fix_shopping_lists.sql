-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_shopping_lists_user_id ON shopping_lists(user_id);
CREATE INDEX IF NOT EXISTS idx_shopping_lists_archived ON shopping_lists(archived);
CREATE INDEX IF NOT EXISTS idx_shopping_list_items_list_id ON shopping_list_items(shopping_list_id);
CREATE INDEX IF NOT EXISTS idx_shopping_list_items_category ON shopping_list_items(category);

-- Add cascade delete for shopping list items
ALTER TABLE shopping_list_items
  DROP CONSTRAINT IF EXISTS shopping_list_items_shopping_list_id_fkey,
  ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey
    FOREIGN KEY (shopping_list_id)
    REFERENCES shopping_lists(id)
    ON DELETE CASCADE;