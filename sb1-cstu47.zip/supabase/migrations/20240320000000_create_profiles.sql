-- Drop existing trigger if it exists
drop trigger if exists on_auth_user_created on auth.users;

-- Drop existing function if it exists
drop function if exists public.handle_new_user();

-- Drop existing table if it exists
drop table if exists profiles;

-- Create profiles table
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  height numeric,
  height_unit text check (height_unit in ('cm', 'in')),
  weight numeric,
  weight_unit text check (weight_unit in ('kg', 'lb')),
  activity_level text check (activity_level in ('not_active', 'moderately_active', 'very_active')),
  primary_goal text check (primary_goal in ('lose_weight', 'maintain_weight', 'gain_muscle', 'eat_healthier')),
  dietary_restrictions text[],
  cooking_for integer,
  subscription_tier text check (subscription_tier in ('free', 'premium')) default 'free',
  subscription_status text check (subscription_status in ('active', 'inactive')) default 'active'
);

-- Create a function to handle new user creation
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id)
  values (new.id);
  return new;
end;
$$ language plpgsql security definer;

-- Create a trigger to automatically create profile records
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();