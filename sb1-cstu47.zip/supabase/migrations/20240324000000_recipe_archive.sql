-- Create a table to archive all generated recipes
create table generated_recipes_archive (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  recipe jsonb not null,
  prompt text,
  preferences jsonb,
  nutritional_targets jsonb
);

-- No RLS needed as this is an internal archive
alter table generated_recipes_archive disable row level security;