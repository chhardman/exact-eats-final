-- Add created_by column to recipes table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'recipes' 
        AND column_name = 'created_by'
    ) THEN
        ALTER TABLE recipes 
        ADD COLUMN created_by uuid references auth.users(id);
    END IF;
END $$;

-- Drop existing policies
DROP POLICY IF EXISTS "Recipes are viewable by all users" ON recipes;
DROP POLICY IF EXISTS "Anyone can view recipes" ON recipes;
DROP POLICY IF EXISTS "Users can create recipes" ON recipes;
DROP POLICY IF EXISTS "Recipe creators can update their recipes" ON recipes;

-- Create new policies
CREATE POLICY "Anyone can view recipes"
  ON recipes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create recipes"
  ON recipes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by OR created_by IS NULL);

CREATE POLICY "Recipe creators can update their recipes"
  ON recipes FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);