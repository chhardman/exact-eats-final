-- Add subscription tracking columns to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS meal_plans_generated_this_month integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS shopping_list_optimizations_used boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS stripe_customer_id text,
ADD COLUMN IF NOT EXISTS stripe_subscription_id text,
ADD COLUMN IF NOT EXISTS subscription_period_end timestamp with time zone,
ADD COLUMN IF NOT EXISTS subscription_cancel_at timestamp with time zone;

-- Create subscription_history table
CREATE TABLE IF NOT EXISTS subscription_history (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  user_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  event_type text NOT NULL CHECK (event_type IN (
    'subscription_created',
    'subscription_updated',
    'subscription_cancelled',
    'subscription_renewed',
    'trial_started',
    'trial_ended'
  )),
  subscription_tier text NOT NULL CHECK (subscription_tier IN ('free', 'premium')),
  billing_period text CHECK (billing_period IN ('monthly', 'annual')),
  amount_paid numeric,
  stripe_event_id text
);

-- Create function to reset meal plan count monthly
CREATE OR REPLACE FUNCTION reset_monthly_meal_plan_count()
RETURNS void AS $$
BEGIN
  UPDATE profiles
  SET meal_plans_generated_this_month = 0
  WHERE subscription_tier = 'premium';
END;
$$ LANGUAGE plpgsql;

-- Create a cron job to reset meal plan count monthly
SELECT cron.schedule(
  'reset-meal-plan-count',
  '0 0 1 * *', -- At midnight on the first day of every month
  $$SELECT reset_monthly_meal_plan_count()$$
);

-- Add RLS policies
ALTER TABLE subscription_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their subscription history"
  ON subscription_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_subscription_history_user_id ON subscription_history(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_stripe_customer_id ON profiles(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_profiles_subscription_period_end ON profiles(subscription_period_end);