import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const params = req.body;

    if (!params?.days || !params?.mealTypes?.length) {
      return res.status(400).json({ 
        error: 'Missing required parameters: days and mealTypes are required' 
      });
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt || 'No specific requirements'}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients?.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences?.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

Each recipe must include:
1. Name
2. Brief description
3. List of ingredients with precise measurements
4. Step-by-step instructions
5. Preparation time
6. Cooking time
7. Difficulty level (easy/medium/hard)
8. Nutritional information (calories, protein, carbs, fat)
9. Number of servings

Format the response as a JSON array of recipes. Each recipe must follow this exact structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Generate a complete meal plan following the requirements above. The response must be a valid JSON array of recipes." }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 4000
    });

    const content = response.choices[0].message.content;
    const recipes = JSON.parse(content).recipes;

    if (!Array.isArray(recipes)) {
      throw new Error('Invalid response format from AI');
    }

    return res.status(200).json(recipes);

  } catch (error) {
    console.error('API error:', error);
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'An unexpected error occurred'
    });
  }
}