import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { originalRecipe, preferences } = req.body;

    if (!originalRecipe) {
      return res.status(400).json({ error: 'Original recipe is required' });
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(originalRecipe, null, 2)}

Additional Preferences: ${preferences?.join(', ') || 'None'}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people

Format the response as a JSON object with this exact structure:
{
  "recipe": {
    "name": "string",
    "description": "string",
    "instructions": ["string"],
    "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
    "prep_time_minutes": number,
    "cook_time_minutes": number,
    "difficulty": "easy" | "medium" | "hard",
    "calories": number,
    "protein_grams": number,
    "carbs_grams": number,
    "fat_grams": number,
    "servings": number
  }
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Generate a new recipe that matches the nutritional profile of the original recipe but offers variety in ingredients and preparation method." }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000
    });

    const content = response.choices[0].message.content;
    const { recipe } = JSON.parse(content);

    if (!recipe) {
      throw new Error('Invalid response format from AI');
    }

    return res.status(200).json(recipe);

  } catch (error) {
    console.error('API error:', error);
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'An unexpected error occurred'
    });
  }
}