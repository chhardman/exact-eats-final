/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        terracotta: '#E56B4E',
        'deep-olive': '#4A5D4F',
        'warm-gold': '#F6B74B',
        'burnt-orange': '#D95030',
        'forest-green': '#2C4A3B',
        cream: '#FDF6EC',
        charcoal: '#2C3539',
        'spice-red': '#B54132',
        'honey-yellow': '#FFCB77',
        sage: '#87A878',
      },
      fontFamily: {
        display: ['Playfair Display', 'serif'],
        sans: ['Plus Jakarta Sans', 'sans-serif'],
        body: ['Outfit', 'sans-serif'],
      },
    },
  },
  plugins: [],
}