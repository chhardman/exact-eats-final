import { Handler } from '@netlify/functions';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

function validateRecipe(recipe: any) {
  const requiredFields = [
    'name',
    'description',
    'instructions',
    'ingredients',
    'prep_time_minutes',
    'cook_time_minutes',
    'difficulty',
    'calories',
    'protein_grams',
    'carbs_grams',
    'fat_grams',
    'servings'
  ];

  return requiredFields.every(field => {
    if (field === 'instructions' || field === 'ingredients') {
      return Array.isArray(recipe[field]) && recipe[field].length > 0;
    }
    return recipe[field] !== undefined && recipe[field] !== null;
  });
}

export const handler: Handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      }
    };
  }

  try {
    const { originalRecipe, preferences } = JSON.parse(event.body || '{}');

    if (!originalRecipe || !validateRecipe(originalRecipe)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Invalid or missing recipe data' 
        })
      };
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(originalRecipe, null, 2)}

Additional Preferences: ${preferences?.join(', ') || 'None'}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people

Format the response as a single JSON recipe object following this structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}`;

    const userPrompt = "Generate a new recipe that matches the nutritional profile of the original recipe but offers variety in ingredients and preparation method.";

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    });

    const content = response.content[0].text;
    
    // Find the JSON object in the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          error: 'Failed to generate a valid recipe. Please try again.' 
        })
      };
    }

    let recipe;
    try {
      recipe = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('JSON parse error:', error);
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          error: 'Failed to parse the generated recipe. Please try again.' 
        })
      };
    }

    // Validate the recipe
    if (!validateRecipe(recipe)) {
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          error: 'Invalid recipe format generated. Please try again.' 
        })
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(recipe)
    };
  } catch (error) {
    console.error('API error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred. Please try again.' 
      })
    };
  }
};