import { Handler } from '@netlify/functions';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};

function validateRecipe(recipe: any) {
  const requiredFields = [
    'name',
    'description',
    'instructions',
    'ingredients',
    'prep_time_minutes',
    'cook_time_minutes',
    'difficulty',
    'calories',
    'protein_grams',
    'carbs_grams',
    'fat_grams',
    'servings'
  ];

  return requiredFields.every(field => {
    if (field === 'instructions' || field === 'ingredients') {
      return Array.isArray(recipe[field]) && recipe[field].length > 0;
    }
    return recipe[field] !== undefined && recipe[field] !== null;
  });
}

export const handler: Handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Request body is required' })
      };
    }

    const { params } = JSON.parse(event.body);

    if (!params?.days || !params?.mealTypes?.length) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Missing required parameters: days and mealTypes are required' 
        })
      };
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt || 'No specific requirements'}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients?.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences?.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

For each meal, provide:
1. Recipe name
2. Brief description (2-3 sentences maximum)
3. List of ingredients with precise measurements
4. Step-by-step instructions (clear and concise)
5. Preparation time (realistic estimate)
6. Cooking time (realistic estimate)
7. Difficulty level (easy/medium/hard)
8. Nutritional information per serving (calories, protein, carbs, fat)
9. Number of servings (default to 4 if not specified)

Format the response as a JSON array of recipes. Each recipe must follow this exact structure:
{
  "name": "string",
  "description": "string",
  "instructions": ["string"],
  "ingredients": [{"item": "string", "amount": number, "unit": "string"}],
  "prep_time_minutes": number,
  "cook_time_minutes": number,
  "difficulty": "easy" | "medium" | "hard",
  "calories": number,
  "protein_grams": number,
  "carbs_grams": number,
  "fat_grams": number,
  "servings": number
}`;

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ 
        role: 'user', 
        content: "Generate a complete meal plan following the requirements above. The response must be a valid JSON array of recipes."
      }]
    });

    const content = response.content[0].text;
    
    // Find the JSON array in the response
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to generate a valid meal plan. Please try again.' 
        })
      };
    }

    let recipes;
    try {
      recipes = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('JSON parse error:', error);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to parse the generated meal plan. Please try again.' 
        })
      };
    }

    // Validate the recipes
    if (!Array.isArray(recipes)) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid response format. Please try again.' 
        })
      };
    }

    if (recipes.length !== params.days * params.mealTypes.length) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Incomplete meal plan generated. Please try again.' 
        })
      };
    }

    // Validate each recipe
    const invalidRecipes = recipes.filter(recipe => !validateRecipe(recipe));
    if (invalidRecipes.length > 0) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid recipe format detected. Please try again.' 
        })
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(recipes)
    };
  } catch (error) {
    console.error('API error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred. Please try again.' 
      })
    };
  }
};