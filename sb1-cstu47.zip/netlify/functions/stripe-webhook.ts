import { Handler } from '@netlify/functions';
import Stripe from 'stripe';
import { createClient } from '@supabase/supabase-js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export const handler: Handler = async (event) => {
  try {
    const stripeEvent = stripe.webhooks.constructEvent(
      event.body!,
      event.headers['stripe-signature']!,
      process.env.STRIPE_WEBHOOK_SECRET!
    );

    const { object } = stripeEvent.data;
    const userId = (object as any).metadata?.userId;

    if (!userId) {
      throw new Error('No userId found in event metadata');
    }

    switch (stripeEvent.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = object as Stripe.Subscription;
        
        await supabase
          .from('profiles')
          .update({
            subscription_tier: 'premium',
            subscription_status: 'active',
            stripe_subscription_id: subscription.id,
            stripe_customer_id: subscription.customer as string,
            subscription_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            subscription_cancel_at: subscription.cancel_at 
              ? new Date(subscription.cancel_at * 1000).toISOString()
              : null
          })
          .eq('id', userId);

        await supabase
          .from('subscription_history')
          .insert({
            user_id: userId,
            event_type: stripeEvent.type === 'customer.subscription.created' 
              ? 'subscription_created' 
              : 'subscription_updated',
            subscription_tier: 'premium',
            billing_period: subscription.items.data[0].price.recurring?.interval === 'year'
              ? 'annual'
              : 'monthly',
            amount_paid: subscription.items.data[0].price.unit_amount! / 100,
            stripe_event_id: stripeEvent.id
          });
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = object as Stripe.Subscription;
        
        await supabase
          .from('profiles')
          .update({
            subscription_tier: 'free',
            subscription_status: 'inactive',
            subscription_period_end: null,
            subscription_cancel_at: null
          })
          .eq('id', userId);

        await supabase
          .from('subscription_history')
          .insert({
            user_id: userId,
            event_type: 'subscription_cancelled',
            subscription_tier: 'free',
            stripe_event_id: stripeEvent.id
          });
        break;
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ received: true })
    };
  } catch (error) {
    console.error('Stripe webhook error:', error);
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: error instanceof Error ? error.message : 'Webhook error'
      })
    };
  }
}