import express from 'express';
import Anthropic from '@anthropic-ai/sdk';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

app.post('/api/generate-meal-plan', async (req, res) => {
  try {
    const params = req.body;

    if (!params?.days || !params?.mealTypes?.length) {
      return res.status(400).json({ 
        error: 'Missing required parameters: days and mealTypes are required' 
      });
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a meal plan based on the following requirements:

Days: ${params.days}
User's Description: ${params.prompt || 'No specific requirements'}
${params.totalCalories ? `Daily Calories Target: ${params.totalCalories}` : ''}
${params.proteinGoal ? `Daily Protein Goal: ${params.proteinGoal}g` : ''}
${params.carbsGoal ? `Daily Carbs Goal: ${params.carbsGoal}g` : ''}
${params.fatGoal ? `Daily Fat Goal: ${params.fatGoal}g` : ''}
Meal Types: ${params.mealTypes.join(', ')}
${params.excludedIngredients?.length ? `Excluded Ingredients: ${params.excludedIngredients.join(', ')}` : ''}
${params.preferences?.length ? `Additional Preferences: ${params.preferences.join(', ')}` : ''}

Generate ${params.days * params.mealTypes.length} recipes total, ensuring even distribution across days and meal types.

Each recipe must include:
1. Name
2. Brief description
3. List of ingredients with precise measurements
4. Step-by-step instructions
5. Preparation time
6. Cooking time
7. Difficulty level (easy/medium/hard)
8. Nutritional information (calories, protein, carbs, fat)
9. Number of servings`;

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ 
        role: 'user', 
        content: 'Generate a complete meal plan following the requirements above. The response must be a valid JSON array of recipes.'
      }]
    });

    const content = response.content[0].text;
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    
    if (!jsonMatch) {
      return res.status(500).json({ 
        error: 'Failed to generate a valid meal plan. Please try again.' 
      });
    }

    const recipes = JSON.parse(jsonMatch[0]);
    return res.status(200).json(recipes);

  } catch (error) {
    console.error('API error:', error);
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'An unexpected error occurred'
    });
  }
});

app.post('/api/regenerate-meal', async (req, res) => {
  try {
    const { originalRecipe, preferences } = req.body;

    if (!originalRecipe) {
      return res.status(400).json({ error: 'Original recipe is required' });
    }

    const systemPrompt = `You are a professional chef and nutritionist. Generate a new recipe similar to the following recipe but with some variation, maintaining similar nutritional values:

Original Recipe:
${JSON.stringify(originalRecipe, null, 2)}

Additional Preferences: ${preferences?.join(', ') || 'None'}

Generate a single recipe that:
1. Matches the nutritional profile (within 10% variance)
2. Has similar preparation difficulty
3. Takes about the same time to prepare
4. Serves the same number of people`;

    const response = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 4096,
      temperature: 0.7,
      system: systemPrompt,
      messages: [{ 
        role: 'user', 
        content: 'Generate a new recipe that matches the nutritional profile of the original recipe but offers variety in ingredients and preparation method.'
      }]
    });

    const content = response.content[0].text;
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      return res.status(500).json({ 
        error: 'Failed to generate a valid recipe. Please try again.' 
      });
    }

    const recipe = JSON.parse(jsonMatch[0]);
    return res.status(200).json(recipe);

  } catch (error) {
    console.error('API error:', error);
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'An unexpected error occurred'
    });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});